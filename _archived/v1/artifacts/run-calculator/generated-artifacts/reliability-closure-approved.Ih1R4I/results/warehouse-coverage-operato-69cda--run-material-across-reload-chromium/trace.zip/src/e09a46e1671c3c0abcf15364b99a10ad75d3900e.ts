/**
 * E2E: the manager's real Inventory tab surfaces warehouse transfer coverage.
 *
 * The fixture is deliberately database-backed for inventory/catalog state and
 * local-storage-backed for the disposable run plan. This keeps the browser
 * journey on the same data paths used by production without relying on shared
 * factory data.
 */

import { expect, test, type APIRequestContext, type Page } from "@playwright/test";
import { Client } from "pg";
import { attachVisualEvidence } from "./captureVisualEvidence";
import {
  AuthorizedBrowserFixtures,
  cleanupTestUsers,
  requireIsolatedTestDatabase,
  uniqueTestId,
} from "./isolation";

const PASSWORD = "TestPass123!";
const SIGNUP_CODE = process.env.STAFF_SIGNUP_CODE ?? "";
const API_BASE =
  process.env.PLAYWRIGHT_BASE_URL ?? `https://${process.env.REPLIT_DEV_DOMAIN}`;
const testUsernames = new Set<string>();

const fixture = {
  ingredientId: uniqueTestId("warehouse_ingredient"),
  ingredientName: `Warehouse E2E Cheese ${uniqueTestId("name")}`,
  itemKey: "",
  itemName: "",
  locationName: `Warehouse E2E Overflow ${uniqueTestId("location")}`,
  itemId: 0,
  locationId: 0,
  onsiteId: 0,
};
fixture.itemKey = `ingredient:${fixture.ingredientName}:lbs`;
fixture.itemName = `Warehouse E2E Product ${uniqueTestId("product")}`;

async function createManager(
  request: APIRequestContext,
  db: Client,
  username: string,
): Promise<string> {
  const response = await request.post(`${API_BASE}/api/auth/sign-up`, {
    headers: { "Content-Type": "application/json" },
    data: { username, password: PASSWORD, accessCode: SIGNUP_CODE },
  });
  expect(response.ok(), `sign-up failed: ${response.status()}`).toBe(true);
  const { token } = await response.json() as { token: string };

  const user = await db.query<{ id: string }>(
    "SELECT id FROM users WHERE username = $1",
    [username],
  );
  expect(user.rows).toHaveLength(1);
  await db.query(
    `INSERT INTO user_roles (user_id, role) VALUES ($1, 'manager')
     ON CONFLICT (user_id) DO UPDATE SET role = 'manager'`,
    [user.rows[0].id],
  );
  await db.query(
    "UPDATE roles SET capabilities = $1::jsonb WHERE name = 'manager'",
    [
      JSON.stringify([
        "manage-staff",
        "manage-inventory",
        "manage-profiles",
        "use-ai-tools",
      ]),
    ],
  );
  await db.query("UPDATE users SET onboarding_seen = true WHERE id = $1", [
    user.rows[0].id,
  ]);
  return token;
}

async function createStaff(
  request: APIRequestContext,
  db: Client,
  username: string,
): Promise<string> {
  const response = await request.post(`${API_BASE}/api/auth/sign-up`, {
    headers: { "Content-Type": "application/json" },
    data: { username, password: PASSWORD, accessCode: SIGNUP_CODE },
  });
  expect(response.ok(), `sign-up failed: ${response.status()}`).toBe(true);
  const { token } = await response.json() as { token: string };

  const user = await db.query<{ id: string }>(
    "SELECT id FROM users WHERE username = $1",
    [username],
  );
  expect(user.rows).toHaveLength(1);
  await db.query(
    `INSERT INTO user_roles (user_id, role) VALUES ($1, 'operator')
     ON CONFLICT (user_id) DO UPDATE SET role = 'operator'`,
    [user.rows[0].id],
  );
  await db.query("UPDATE users SET onboarding_seen = true WHERE id = $1", [
    user.rows[0].id,
  ]);
  return token;
}

async function openAuthenticated(page: Page, token: string): Promise<void> {
  await page.context().addCookies([{ name: "rc_auth", value: token, url: API_BASE }]);
  await page.goto("/", { waitUntil: "domcontentloaded" });
  await page.getByTestId("tab-run").waitFor({ state: "attached", timeout: 25_000 });
}

async function openInventory(page: Page, expectCoverage = true): Promise<void> {
  await page.locator('button[title="More"]').click();
  await page.getByRole("menuitem", { name: "Inventory", exact: true }).click();
  if (expectCoverage) {
    await expect(page.getByTestId("warehouse-coverage")).toBeVisible();
  }
}

async function seedRun(page: Page, runId: string): Promise<void> {
  await page.waitForLoadState("domcontentloaded");
  await expect(page).toHaveURL(/\/(?:#.*)?$/);
  await page.addInitScript(
    ({ id, ingredientName }) => {
      if (sessionStorage.getItem("warehouse-coverage-seed-applied") === "1") return;
      sessionStorage.setItem("warehouse-coverage-seed-applied", "1");
      const now = new Date();
      const date = [
        now.getFullYear(),
        String(now.getMonth() + 1).padStart(2, "0"),
        String(now.getDate()).padStart(2, "0"),
      ].join("-");
      const values = {
        casesNeeded: 1,
        pizzasPerCase: 10,
        app1Type: ingredientName,
        app1OzPerPizza: 1,
      };
      localStorage.setItem(`run-calc-run-${id}`, JSON.stringify(values));
      localStorage.setItem(
        "run-calc-day",
        JSON.stringify({
          date,
          runs: [{ id, brand: "Warehouse E2E", flavor: "Coverage", casesNeeded: 1 }],
          runValues: { [id]: values },
          currentIndex: 0,
          resetAt: 0,
        }),
      );
    },
    { id: runId, ingredientName: fixture.ingredientName },
  );
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.getByTestId("tab-run").waitFor({ state: "attached", timeout: 25_000 });
}

type SwitchoverFixture = {
  date: string;
  runId: string;
  nextRunId: string;
};

function localDate(): string {
  const now = new Date();
  return [
    now.getFullYear(),
    String(now.getMonth() + 1).padStart(2, "0"),
    String(now.getDate()).padStart(2, "0"),
  ].join("-");
}

async function seedRunningSwitchoverRun(
  _request: APIRequestContext,
  token: string,
  runId: string,
  nextRunId: string,
): Promise<SwitchoverFixture> {
  const date = localDate();
  const seedStamp = Date.now();
  const values = {
    casesNeeded: 200,
    pizzasPerCase: 12,
    casesPerSkid: 20,
    skidsCompleted: 9,
    casesOnCurrentSkid: 8,
    crustsPerCycle: 10,
    cycleSpeed: 1,
    speedAdjustment: 1,
    freezerTime: 10,
    app1Type: "",
    app2Type: "",
    app3Type: "",
    app4Type: "",
    pep1Type: "",
    pep2Type: "",
    pep1TypeB: "",
    pep2TypeB: "",
  };
  const payload = {
    dayState: {
      date,
      runs: [
        {
          id: runId,
          brand: "Warehouse E2E",
          flavor: "Switchover",
          startedAt: seedStamp,
          metaUpdatedAt: seedStamp,
        },
        {
          id: nextRunId,
          brand: "Next Brand",
          flavor: "Next Flavor",
          metaUpdatedAt: seedStamp,
        },
      ],
      currentIndex: 0,
      currentRunId: runId,
      resetAt: 0,
    },
    runValues: {
      [runId]: values,
      [nextRunId]: {
        casesNeeded: 100,
        pizzasPerCase: 12,
        casesPerSkid: 20,
        app1Type: "",
        app2Type: "",
        app3Type: "",
        app4Type: "",
        pep1Type: "",
        pep2Type: "",
        pep1TypeB: "",
        pep2TypeB: "",
      },
    },
    runValuesUpdatedAt: {
      [runId]: seedStamp,
      [nextRunId]: seedStamp,
    },
  };

  const db = new Client({ connectionString: requireIsolatedTestDatabase("Warehouse switchover fixture") });
  try {
    await db.connect();
    await db.query(
      "DELETE FROM daily_sync WHERE date = $1 AND scope = 'live'",
      [date],
    );
  } finally {
    await db.end().catch(() => {});
  }

  // Started/counter facts are server-owned. Initialize this disposable
  // canonical snapshot through the existing isolated-fixture boundary, not
  // an ordinary client PUT that must continue rejecting operational facts.
  await authorizedFixtures.seedCanonicalTodaySnapshot({
    token,
    senderId: uniqueTestId("warehouse-switchover-seed"),
    date,
    payload,
  });

  return { date, runId, nextRunId };
}

async function removeSwitchoverFixture(fixture: SwitchoverFixture): Promise<void> {
  const db = new Client({ connectionString: requireIsolatedTestDatabase("remove Warehouse switchover fixture") });
  try {
    await db.connect();
    await db.query(
      `UPDATE daily_sync
       SET data = jsonb_set(
         jsonb_set(
           data,
           '{dayState,runs}',
           COALESCE((
             SELECT jsonb_agg(run)
             FROM jsonb_array_elements(COALESCE(data->'dayState'->'runs', '[]'::jsonb)) AS run
             WHERE run->>'id' NOT IN ($1, $2)
           ), '[]'::jsonb)
         ),
         '{runValues}',
         COALESCE((
           SELECT jsonb_object_agg(key, value)
           FROM jsonb_each(COALESCE(data->'runValues', '{}'::jsonb))
           WHERE key NOT IN ($1, $2)
         ), '{}'::jsonb)
       )
       WHERE date = $3 AND scope = 'live'`,
      [fixture.runId, fixture.nextRunId, fixture.date],
    );
  } finally {
    await db.end().catch(() => {});
  }
}

async function seedInventory(db: Client): Promise<void> {
  const onsite = await db.query<{ id: number }>(
    "SELECT id FROM inventory_locations WHERE scope = 'live' AND is_onsite = true ORDER BY id LIMIT 1",
  );
  if (onsite.rows.length === 0) {
    const created = await db.query<{ id: number }>(
      `INSERT INTO inventory_locations (scope, name, is_onsite)
       VALUES ('live', 'Onsite (Line)', true) RETURNING id`,
    );
    fixture.onsiteId = created.rows[0].id;
  } else {
    fixture.onsiteId = onsite.rows[0].id;
  }

  const location = await db.query<{ id: number }>(
    `INSERT INTO inventory_locations (scope, name, is_onsite)
     VALUES ('live', $1, false) RETURNING id`,
    [fixture.locationName],
  );
  fixture.locationId = location.rows[0].id;

  const ingredient = await db.query(
    `INSERT INTO ingredients (id, scope, name, categories)
     VALUES ($1, 'live', $2, $3::jsonb)`,
    [fixture.ingredientId, fixture.ingredientName, JSON.stringify(["general"])],
  );
  expect(ingredient.rowCount).toBe(1);

  const item = await db.query<{ id: number }>(
    `INSERT INTO inventory_items
       (scope, key, category, name, unit, production_ingredient_id, conversion_factor)
     VALUES ('live', $1, 'ingredient', $2, 'lbs', $3, 10)
     RETURNING id`,
    [fixture.itemKey, fixture.itemName, fixture.ingredientId],
  );
  fixture.itemId = item.rows[0].id;

  // One unit offsite = 10 production lbs; demand is 10 lbs and onsite starts
  // empty, so the UI should cap the guidance at the exact shortfall.
  await db.query(
    `INSERT INTO inventory_lots
       (scope, item_id, location_id, qty_received, qty_remaining)
     VALUES
       ('live', $1, $2, 0.9, 0.9),
       ('live', $1, $3, 0, 0)`,
    [fixture.itemId, fixture.locationId, fixture.onsiteId],
  );
}

async function cleanupInventory(db: Client): Promise<void> {
  if (fixture.itemId) {
    await db.query("DELETE FROM inventory_items WHERE id = $1", [fixture.itemId]);
  }
  if (fixture.ingredientId) {
    await db.query(
      "DELETE FROM ingredients WHERE id = $1 AND scope = 'live'",
      [fixture.ingredientId],
    );
  }
  if (fixture.locationId) {
    await db.query("DELETE FROM inventory_locations WHERE id = $1", [fixture.locationId]);
  }
}

const managerUsername = uniqueTestId("warehouse_manager");
const staffUsername = uniqueTestId("warehouse_staff");
let managerToken = "";
let staffToken = "";
let authorizedFixtures: AuthorizedBrowserFixtures;

test.beforeAll(async ({ request, playwright }) => {
  await requireIsolatedTestDatabase("warehouse coverage browser check");
  authorizedFixtures = await AuthorizedBrowserFixtures.create(playwright, API_BASE, SIGNUP_CODE);
  const db = new Client({ connectionString: process.env.DATABASE_URL });
  try {
    await db.connect();
    testUsernames.add(managerUsername);
    testUsernames.add(staffUsername);
    managerToken = await createManager(request, db, managerUsername);
    staffToken = await createStaff(request, db, staffUsername);
  } finally {
    await db.end().catch(() => {});
  }
});


test.afterAll(async () => {
  try {
    await authorizedFixtures?.cleanup();
  } finally {
    if (process.env.DATABASE_URL) {
      const db = new Client({ connectionString: process.env.DATABASE_URL });
      try {
        await db.connect();
        await cleanupTestUsers(db, testUsernames);
      } finally {
        await db.end().catch(() => {});
      }
    }
  }
});

test.afterEach(async () => {
  if (!process.env.DATABASE_URL) return;
  const db = new Client({ connectionString: process.env.DATABASE_URL });
  try {
    await db.connect();
    await cleanupInventory(db);
  } finally {
    await db.end().catch(() => {});
  }
});

test("operator staging check persists for a canonical per-run material across reload", async ({
  page,
}, testInfo) => {
  const runId = uniqueTestId("warehouse_staging_run");
  const brand = `Warehouse E2E ${uniqueTestId("brand")}`;
  const material = `Warehouse E2E Topping ${uniqueTestId("material")}`;
  const date = await page.evaluate(() => {
    const now = new Date();
    return [
      now.getFullYear(),
      String(now.getMonth() + 1).padStart(2, "0"),
      String(now.getDate()).padStart(2, "0"),
    ].join("-");
  });
  const seededAt = Date.now();
  const payload = {
    dayState: {
      date,
      runs: [{
        id: runId,
        brand,
        flavor: "Staging",
        startedAt: seededAt,
        metaUpdatedAt: seededAt,
      }],
      currentIndex: 0,
      currentRunId: runId,
      resetAt: 0,
      substitutions: [],
      substitutionLog: [],
      stagedItems: {},
    },
    runValues: {
      [runId]: {
        casesNeeded: 1,
        pizzasPerCase: 10,
        app1Type: material,
        app1OzPerPizza: 1,
      },
    },
    runValuesUpdatedAt: { [runId]: seededAt },
  };
  await authorizedFixtures.seedCanonicalTodaySnapshot({
    token: managerToken,
    senderId: uniqueTestId("warehouse-staging-seed"),
    date,
    payload,
  });

  const browserErrors: string[] = [];
  page.on("pageerror", (error) => browserErrors.push(error.message));
  page.on("response", (response) => {
    if (response.status() >= 500) {
      browserErrors.push(`${response.status()} ${response.request().method()} ${response.url()}`);
    }
  });
  await page.setViewportSize({ width: 1440, height: 900 });
  await openAuthenticated(page, staffToken);
  await expect(page.getByTestId("tab-warehouse")).toBeVisible();
  await page.getByTestId("tab-warehouse").click();

  const details = page.getByTestId("warehouse-run-details");
  await expect(details).toBeVisible();
  await details.locator("summary").click();
  const stageButton = page.getByTestId(`stage-${runId}-${material}__lbs`);
  await expect(stageButton).toBeVisible();
  await expect(stageButton).toHaveAttribute("aria-pressed", "false");
  await stageButton.click();
  await expect(stageButton).toHaveAttribute("aria-pressed", "true");
  await attachVisualEvidence(page, testInfo, "operator-warehouse-staging-before-reload");

  const readSavedStage = async (): Promise<string | null> => {
    const db = new Client({ connectionString: process.env.DATABASE_URL });
    try {
      await db.connect();
      const result = await db.query<{ staged: string | null }>(
        `SELECT data->'dayState'->'stagedItems'->>$1 AS staged
         FROM daily_sync WHERE date = $2 AND scope = 'live'`,
        [`${runId}::${material}__lbs`, date],
      );
      return result.rows[0]?.staged ?? null;
    } finally {
      await db.end().catch(() => {});
    }
  };
  await expect.poll(readSavedStage, { timeout: 20_000 }).toBe("true");

  await page.reload({ waitUntil: "domcontentloaded" });
  await page.getByTestId("tab-run").waitFor({ state: "attached", timeout: 25_000 });
  await page.getByTestId("tab-warehouse").click();
  await expect(details).toBeVisible();
  await details.locator("summary").click();
  const reloadedStageButton = page.getByTestId(`stage-${runId}-${material}__lbs`);
  await expect(reloadedStageButton).toHaveAttribute("aria-pressed", "true");
  await attachVisualEvidence(page, testInfo, "operator-warehouse-staging-after-reload");

  for (const viewport of [
    { width: 390, height: 844 },
    { width: 768, height: 1024 },
    { width: 1024, height: 768 },
  ]) {
    await page.setViewportSize(viewport);
    await page.reload({ waitUntil: "domcontentloaded" });
    await page.getByTestId("tab-run").waitFor({ state: "attached", timeout: 25_000 });
    await page.getByTestId("tab-warehouse").click();
    await expect(details).toBeVisible();
    await details.locator("summary").click();
    const responsiveStageButton = page.getByTestId(`stage-${runId}-${material}__lbs`);
    await expect(responsiveStageButton).toHaveAttribute("aria-pressed", "true");
    await responsiveStageButton.scrollIntoViewIfNeeded();
    await expect(responsiveStageButton).toBeInViewport();
    await attachVisualEvidence(
      page,
      testInfo,
      `operator-warehouse-staging-${viewport.width}x${viewport.height}`,
    );
  }

  await reloadedStageButton.click();
  await expect(reloadedStageButton).toHaveAttribute("aria-pressed", "false");
  await expect.poll(readSavedStage, { timeout: 20_000 }).toBeNull();
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.getByTestId("tab-run").waitFor({ state: "attached", timeout: 25_000 });
  await page.getByTestId("tab-warehouse").click();
  await expect(details).toBeVisible();
  await details.locator("summary").click();
  await expect(page.getByTestId(`stage-${runId}-${material}__lbs`))
    .toHaveAttribute("aria-pressed", "false");
  expect(browserErrors).toEqual([]);
});

test("shows capped offsite transfer guidance and hides it when onsite stock covers demand", async ({
  page,
}, testInfo) => {
  const runId = uniqueTestId("warehouse_run");
  const browserErrors: string[] = [];
  page.on("pageerror", (error) => browserErrors.push(error.message));
  page.on("response", (response) => {
    if (response.status() >= 500) {
      browserErrors.push(`${response.status()} ${response.request().method()} ${response.url()}`);
    }
  });

  const db = new Client({ connectionString: process.env.DATABASE_URL });
  try {
    await db.connect();
    await seedInventory(db);
    await openAuthenticated(page, managerToken);
    await seedRun(page, runId);
    await openInventory(page);

    const coverage = page.getByTestId("warehouse-coverage");
    const row = coverage
      .getByText(fixture.ingredientName, { exact: true })
      .locator("xpath=../..");
    await expect(row).toContainText("Short");
    await expect(row).toContainText(`Can cover 9 lbs from 9 lbs from ${fixture.locationName}.`);
    await page.screenshot({
      path: testInfo.outputPath("warehouse-coverage-offsite-guidance.png"),
      fullPage: true,
    });
    await page.screenshot({
      path: testInfo.outputPath("warehouse-coverage-offsite-viewport.png"),
    });

    // Add enough stock through the authenticated restock API. This exercises
    // the same update/broadcast path the real Stock UI uses, so the mounted
    // Inventory tab recomputes without relying on an out-of-band DB mutation.
    const restock = await page.evaluate(
      async ({ itemKey, itemName, locationId }) => {
        const response = await fetch("/api/inventory/restock", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            itemKey,
            category: "ingredient",
            name: itemName,
            unit: "lbs",
            qty: 2.1,
            locationId,
          }),
        });
        return response.status;
      },
      {
        itemKey: fixture.itemKey,
        itemName: fixture.itemName,
        locationId: fixture.onsiteId,
      },
    );
    expect(restock).toBe(200);
    await expect(row).toContainText("Covered");
    await expect(row).not.toContainText("Can cover");
    await page.screenshot({
      path: testInfo.outputPath("warehouse-coverage-onsite-covered.png"),
      fullPage: true,
    });
    expect(browserErrors).toEqual([]);
  } finally {
    await db.end().catch(() => {});
  }
});

test("explains restricted inventory actions to non-managers", async ({
  page,
}, testInfo) => {
  const browserErrors: string[] = [];
  page.on("pageerror", (error) => browserErrors.push(error.message));
  page.on("response", (response) => {
    if (response.status() >= 500) {
      browserErrors.push(`${response.status()} ${response.request().method()} ${response.url()}`);
    }
  });

  const db = new Client({ connectionString: process.env.DATABASE_URL });
  try {
    await db.connect();
    await seedInventory(db);
    await openAuthenticated(page, staffToken);
    await openInventory(page, false);

    const itemName = page.getByText(fixture.itemName, { exact: true });
    await expect(itemName).toBeVisible();
    await itemName.click();

    const addStock = page.getByRole("button", { name: "Add stock", exact: true });
    await expect(addStock).toBeVisible();
    await page.getByLabel(`Restock quantity for ${fixture.itemName}`, { exact: true }).fill("1");
    await expect(addStock).toBeEnabled();

    await expect(
      page.getByText(
        "Inventory Manager required to change stock records through manual adjustments. You can still review current inventory and record received stock.",
        { exact: true },
      ),
    ).toBeVisible();
    await expect(
      page.getByText(
        "Inventory Manager required to change stock records through transfers. You can still review current inventory and record received stock.",
        { exact: true },
      ),
    ).toBeVisible();
    await expect(
      page.getByRole("button", { name: "Apply adjustment", exact: true }),
    ).toBeDisabled();
    await expect(
      page.getByRole("button", { name: "Move stock", exact: true }),
    ).toBeDisabled();

    const capabilityStatuses = await page.evaluate(
      async ({ itemId, fromLocationId, toLocationId }) => {
        const [adjust, transfer] = await Promise.all([
          fetch("/api/inventory/adjust", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ itemId, qtyDelta: 1, note: "staff denial check" }),
          }),
          fetch("/api/inventory/transfer", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              itemId,
              fromLocationId,
              toLocationId,
              qty: 0.1,
            }),
          }),
        ]);
        return { adjust: adjust.status, transfer: transfer.status };
      },
      {
        itemId: fixture.itemId,
        fromLocationId: fixture.locationId,
        toLocationId: fixture.onsiteId,
      },
    );
    expect(capabilityStatuses).toEqual({ adjust: 403, transfer: 403 });

    await page.screenshot({
      path: testInfo.outputPath("warehouse-staff-inventory-restrictions.png"),
      fullPage: true,
    });
    expect(browserErrors).toEqual([]);
  } finally {
    await db.end().catch(() => {});
  }
});

test("keeps capped offsite transfer guidance readable on a phone", async ({
  page,
}, testInfo) => {
  await page.setViewportSize({ width: 390, height: 844 });

  const runId = uniqueTestId("warehouse_phone_run");
  const browserErrors: string[] = [];
  page.on("pageerror", (error) => browserErrors.push(error.message));
  page.on("response", (response) => {
    if (response.status() >= 500) {
      browserErrors.push(`${response.status()} ${response.request().method()} ${response.url()}`);
    }
  });

  const db = new Client({ connectionString: process.env.DATABASE_URL });
  try {
    await db.connect();
    await seedInventory(db);
    await openAuthenticated(page, managerToken);
    await seedRun(page, runId);
    await openInventory(page);

    const coverage = page.getByTestId("warehouse-coverage");
    const row = coverage
      .getByText(fixture.ingredientName, { exact: true })
      .locator("xpath=../..");
    const guidance = row.getByText(
      `Can cover 9 lbs from 9 lbs from ${fixture.locationName}.`,
      { exact: true },
    );

    await expect(row).toContainText("Short");
    await expect(guidance).toBeVisible();
    await expect(guidance).toHaveText(
      `Can cover 9 lbs from 9 lbs from ${fixture.locationName}.`,
    );

    const layout = await guidance.evaluate((element) => ({
      clientWidth: element.clientWidth,
      scrollWidth: element.scrollWidth,
      clientHeight: element.clientHeight,
      scrollHeight: element.scrollHeight,
      right: element.getBoundingClientRect().right,
    }));
    expect(layout.scrollWidth).toBe(layout.clientWidth);
    expect(layout.scrollHeight).toBe(layout.clientHeight);
    expect(layout.right).toBeLessThanOrEqual(390);

    const warehouseLabel = page.getByTestId("tab-warehouse").locator("span");
    const warehouseLabelBounds = await warehouseLabel.evaluate((element) => {
      const rect = element.getBoundingClientRect();
      return { height: rect.height, left: rect.left, right: rect.right };
    });
    expect(warehouseLabelBounds.height).toBeLessThanOrEqual(16);
    expect(warehouseLabelBounds.left).toBeGreaterThanOrEqual(0);
    expect(warehouseLabelBounds.right).toBeLessThanOrEqual(390);

    const applySubstitution = page.getByRole("button", {
      name: "Apply substitution",
      exact: true,
    });
    await applySubstitution.scrollIntoViewIfNeeded();
    const applyButtonClearsNav = await applySubstitution.evaluate((button) => {
      const nav = document.querySelector(".station-nav");
      if (!nav) return false;
      const buttonRect = button.getBoundingClientRect();
      const navRect = nav.getBoundingClientRect();
      return buttonRect.top >= 0
        && buttonRect.bottom <= navRect.top
        && navRect.bottom <= window.innerHeight;
    });
    expect(applyButtonClearsNav).toBe(true);
    expect(browserErrors).toEqual([]);

    await page.screenshot({
      path: testInfo.outputPath("warehouse-coverage-phone-guidance.png"),
      fullPage: true,
    });
    await page.screenshot({
      path: testInfo.outputPath("warehouse-coverage-phone-viewport.png"),
    });
    await page.screenshot({
      path: testInfo.outputPath("warehouse-coverage-phone-substitution-form-viewport.png"),
    });
  } finally {
    await db.end().catch(() => {});
  }
});

test("keeps capped offsite transfer guidance readable on a tablet", async ({
  page,
}, testInfo) => {
  const viewport = { width: 768, height: 1024 };
  await page.setViewportSize(viewport);

  const runId = uniqueTestId("warehouse_tablet_run");
  const browserErrors: string[] = [];
  page.on("pageerror", (error) => browserErrors.push(error.message));
  page.on("response", (response) => {
    if (response.status() >= 500) {
      browserErrors.push(`${response.status()} ${response.request().method()} ${response.url()}`);
    }
  });

  const db = new Client({ connectionString: process.env.DATABASE_URL });
  try {
    await db.connect();
    await seedInventory(db);
    await openAuthenticated(page, managerToken);
    await seedRun(page, runId);
    await openInventory(page);

    const coverage = page.getByTestId("warehouse-coverage");
    const row = coverage
      .getByText(fixture.ingredientName, { exact: true })
      .locator("xpath=../..");
    const guidanceText = `Can cover 9 lbs from 9 lbs from ${fixture.locationName}.`;
    const guidance = row.getByText(guidanceText, { exact: true });

    await expect(row).toContainText("Short");
    await expect(guidance).toBeVisible();
    await expect(guidance).toHaveText(guidanceText);

    const layout = await guidance.evaluate((element) => ({
      clientWidth: element.clientWidth,
      scrollWidth: element.scrollWidth,
      clientHeight: element.clientHeight,
      scrollHeight: element.scrollHeight,
      right: element.getBoundingClientRect().right,
    }));
    expect(layout.scrollWidth).toBe(layout.clientWidth);
    expect(layout.scrollHeight).toBe(layout.clientHeight);
    expect(layout.right).toBeLessThanOrEqual(viewport.width);
    expect(browserErrors).toEqual([]);

    await page.screenshot({
      path: testInfo.outputPath("warehouse-coverage-tablet-guidance.png"),
      fullPage: true,
    });
    await page.screenshot({
      path: testInfo.outputPath("warehouse-coverage-tablet-viewport.png"),
    });

    await page.reload({ waitUntil: "domcontentloaded" });
    await expect(page.getByTestId("warehouse-coverage")).toBeVisible();

    const reloadedCoverage = page.getByTestId("warehouse-coverage");
    const reloadedRow = reloadedCoverage
      .getByText(fixture.ingredientName, { exact: true })
      .locator("xpath=../..");
    const reloadedGuidance = reloadedRow.getByText(guidanceText, { exact: true });

    await expect(reloadedRow).toContainText("Short");
    await expect(reloadedGuidance).toBeVisible();
    await expect(reloadedGuidance).toHaveText(guidanceText);

    const reloadedLayout = await reloadedGuidance.evaluate((element) => ({
      clientWidth: element.clientWidth,
      scrollWidth: element.scrollWidth,
      clientHeight: element.clientHeight,
      scrollHeight: element.scrollHeight,
      right: element.getBoundingClientRect().right,
    }));
    expect(reloadedLayout.scrollWidth).toBe(reloadedLayout.clientWidth);
    expect(reloadedLayout.scrollHeight).toBe(reloadedLayout.clientHeight);
    expect(reloadedLayout.right).toBeLessThanOrEqual(viewport.width);
    expect(browserErrors).toEqual([]);
  } finally {
    await db.end().catch(() => {});
  }
});

test("shows the Warehouse switchover handoff through real tab navigation", async ({
  page,
  request,
}, testInfo) => {
  const runId = uniqueTestId("warehouse_switchover_run");
  const nextRunId = uniqueTestId("warehouse_switchover_next");
  const browserErrors: string[] = [];
  let switchoverFixture: SwitchoverFixture | undefined;
  page.on("pageerror", (error) => browserErrors.push(error.message));
  page.on("response", (response) => {
    if (response.status() >= 500) {
      browserErrors.push(`${response.status()} ${response.request().method()} ${response.url()}`);
    }
  });

  try {
    switchoverFixture = await seedRunningSwitchoverRun(
      request,
      managerToken,
      runId,
      nextRunId,
    );
    await page.addInitScript((marker) => {
      if (location.origin === "null" || sessionStorage.getItem(marker) === "1") return;
      sessionStorage.setItem(marker, "1");
      for (const key of Array.from({ length: localStorage.length }, (_, index) =>
        localStorage.key(index),
      )) {
        if (key?.startsWith("run-calc")) localStorage.removeItem(key);
      }
    }, `warehouse-switchover-cleanup-${runId}`);
    await openAuthenticated(page, managerToken);
    await expect(page.getByTestId("operational-state-badge")).toHaveText(
      "Confirmed server baseline",
      { timeout: 15_000 },
    );
    await expect(page.getByRole("button", { name: /pause run/i })).toBeVisible();

    const banner = page.getByTestId("banner-warehouse-switchover");
    await expect(banner).toBeHidden();

    await page.getByTestId("tab-warehouse").click();
    await expect(page.getByTestId("warehouse-page-heading")).toBeVisible();
    await expect(banner).toBeVisible();
    await expect(banner).toContainText(
      "0.6 skids to switchover — stage packaging for the next run",
    );
    await expect(banner).toContainText(
      "frontline should already be staged; packaging goes now",
    );
    await expect(banner).toContainText("12 cases left at the press");
    await expect(banner).toContainText(/press stops ~\d{1,2}:\d{2}/);
    await expect(banner).toContainText(/line clear ~\d{1,2}:\d{2}/);
    await expect(banner).toContainText("Next up: Next Brand – Next Flavor.");
    await page.screenshot({
      path: testInfo.outputPath("warehouse-switchover-handoff.png"),
      fullPage: true,
    });

    await page.getByTestId("tab-run").click();
    await expect(banner).toBeHidden();

    const stopButton = page.getByRole("button", { name: "STOP RUN", exact: true });
    await expect(stopButton).toBeVisible();
    await stopButton.click();
    await expect(stopButton).toBeHidden({ timeout: 15_000 });
    await expect.poll(
      () =>
        page.evaluate((id) => {
          const day = JSON.parse(localStorage.getItem("run-calc-day") ?? "{}") as {
            runs?: Array<{ id?: string; endedAt?: number }>;
          };
          return day.runs?.find((run) => run.id === id)?.endedAt ?? null;
        }, runId),
      { timeout: 15_000 },
    ).toBeTruthy();

    await page.getByTestId("tab-warehouse").click();
    await expect(banner).toBeHidden();
    expect(browserErrors).toEqual([]);
  } finally {
    if (switchoverFixture) {
      await removeSwitchoverFixture(switchoverFixture);
    }
  }
});
