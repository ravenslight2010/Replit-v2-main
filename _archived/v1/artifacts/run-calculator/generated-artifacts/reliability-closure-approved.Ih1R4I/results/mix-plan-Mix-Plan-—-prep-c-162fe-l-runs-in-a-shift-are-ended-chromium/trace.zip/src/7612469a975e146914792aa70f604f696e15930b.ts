/**
 * E2E: Mix Plan — prep card suppression, ended-run removal, and pull quantities
 *
 * Behaviours verified end-to-end:
 *
 *   (a) A prep mix card is absent when no active run on the selected day
 *       lists any of the prep mix's component ingredients.
 *
 *   (b) A mix card disappears from the Make Day plan once the manager clicks
 *       STOP RUN.
 *
 *   (c) Ending ONE run in a two-run shift keeps the OTHER run's mix card.
 *
 *   (d) A prep mix card shows correct "Pull For Prep" quantities when a run
 *       DOES list the component ingredient (amountAlreadyMade = 0).
 *
 *   (e) Per-run breakdown is correct when two brands share an ingredient
 *       (amountAlreadyMade = 0).
 *
 *   (f) Pull For Prep is reduced proportionally when amountAlreadyMade > 0
 *       (single run).
 *
 *   (g) Pull For Prep shows 0.00 lbs when amountAlreadyMade >= totalLbs.
 *
 *   (h) Pull For Prep is scaled proportionally when TWO runs share an
 *       ingredient and amountAlreadyMade > 0 (Task #764 target).
 *
 *   (i) Badge updates live when the "Already made" input is edited.
 *
 *   (j) Mix plan collapses to empty when ALL runs in a shift are ended.
 *
 *   (k) Empty state is preserved after a full page reload when all runs are
 *       ended — exercises the localStorage + React hydration path separately
 *       from the in-memory state path.
 *
 *   (l) Batch count is correct on cold load when amountAlreadyMade is already
 *       persisted in the DB — the server fetch must wire amountAlreadyMade into
 *       buildMixPlan so the first render shows floor(remainingLbs / batchSize)
 *       using the stored value, not 0.
 *
 *   (m) Pull For Mix per-component lbs on a regular mix card update live when
 *       "already made" is edited (Task #799).
 *       — Full lbs shown initially (amountAlreadyMade=0).
 *       — Scaled lbs shown after a partial already-made entry.
 *       — 0.00 shown after already-made >= totalLbs.
 *
 * Relevant files:
 *   artifacts/run-calculator/src/pages/home.tsx  — mix plan section, ~14402–14700
 *   lib/mixes/src/index.ts          — buildMixPlan, computeEntryFromComponentLbs
 *   artifacts/api-server/src/routes/mixes.ts — POST /api/mixes
 */

import { test, expect, type Locator, type Page } from "@playwright/test";
import { Client } from "pg";
import {
  AuthorizedBrowserFixtures,
  DEFAULT_MANAGER_CAPABILITIES,
  requireIsolatedTestDatabase,
} from "./isolation";
import {
  dismissOnboardingIfPresent,
  signUpAndHandleOnboarding,
} from "./onboarding";

// ── helpers ──────────────────────────────────────────────────────────────────

function uid(): string {
  return `e2emp${Math.random().toString(36).slice(2, 9)}`;
}

const SIGNUP_CODE = process.env.STAFF_SIGNUP_CODE ?? "";
const API_BASE =
  process.env.PLAYWRIGHT_BASE_URL
  ?? (process.env.RELEASE_BROWSER_LOCAL_SERVERS === "1"
    ? `http://127.0.0.1:${process.env.RELEASE_BROWSER_WEB_PORT ?? "18084"}`
    : `https://${process.env.REPLIT_DEV_DOMAIN}`);
async function closeOnboardingIfVisible(page: Page): Promise<void> {
  await dismissOnboardingIfPresent(page);
}

async function waitForAppAfterNavigation(page: Page): Promise<void> {
  await page
    .locator('[data-testid="tab-run"]')
    .waitFor({ state: "attached", timeout: 25_000 });

  await closeOnboardingIfVisible(page);

  // The tab can mount before the authenticated shell has finished restoring
  // its controls. Waiting for the menu makes the next navigation deterministic
  // instead of relying on a fixed sleep after reload.
  await page.locator('button[title="More"]').waitFor({
    state: "visible",
    timeout: 15_000,
  });

  // On a reload the onboarding dialog can finish mounting just after the
  // shell controls become visible. Check once more immediately before using
  // the menu so a late dialog cannot intercept the click.
  await closeOnboardingIfVisible(page);
}

async function dismissOnboarding(page: Page): Promise<void> {
  await closeOnboardingIfVisible(page);
}

async function signUpAndDismissOnboarding(
  page: Page,
  username: string,
  password: string,
): Promise<void> {
  await signUpAndHandleOnboarding(page, username, password, {
    signupCode: SIGNUP_CODE,
    waitForApp: async (currentPage) => {
      await currentPage
        .locator('[data-testid="tab-run"]')
        .waitFor({ state: "attached", timeout: 25_000 });
    },
    afterSignUp: async (currentPage) => {
      await currentPage.waitForTimeout(300);

      // A newly-created account can have the initial run only in React state
      // until the first form interaction. Direct-fixture tests need a durable
      // local baseline before they mutate run-calc-day and reload.
      await currentPage.evaluate((user) => {
        if (localStorage.getItem("run-calc-day")) return;
        const runId = `e2e-bootstrap-run-${user}`;
        localStorage.setItem("run-calc-day", JSON.stringify({
          runs: [{ id: runId, brand: "", flavor: "", seeded: false }],
          currentIndex: 0,
          date: new Date().toISOString().slice(0, 10),
          // Today's resetAt is also the server's auth boundary. Keep this
          // same-day fixture at the stable baseline instead of manufacturing a
          // future reset that can invalidate the account's just-issued session.
          resetAt: 0,
          substitutions: [],
          substitutionLog: [],
          stagedItems: {},
          prepPhase: { prepStartedAt: null, prepBatchesDough: 0, prepBatchesSauce: 0, prepCarriedOver: false },
        }));
        localStorage.setItem(`run-calc-run-${runId}`, JSON.stringify({}));
      }, username);
      await dbSeedCanonicalDayFromPage(currentPage);
    },
  });
}

async function goToMixes(page: Page): Promise<void> {
  await waitForAppAfterNavigation(page);
  const menuBtn = page.locator('button[title="More"]');
  await menuBtn.click();
  const mixesItem = page.getByRole("menuitem", { name: /^(mixes|mix plan)$/i });
  await mixesItem.waitFor({ state: "visible", timeout: 5_000 });
  await mixesItem.click();
  await page
    .locator('[data-testid="mix-make-day"]')
    .waitFor({ state: "visible", timeout: 8_000 });
}

async function waitForTodayMixPlanCard(page: Page, today: string): Promise<Locator> {
  const card = page.locator(`[data-testid="mix-plan-${today}"]`);
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      await card.waitFor({ state: "visible", timeout: 20_000 });
      return card;
    } catch (error) {
      if (attempt === 2) throw error;
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]')
        .waitFor({ state: "attached", timeout: 25_000 });
      await goToMixes(page);
    }
  }
  return card;
}

/**
 * Seed a live run before the authenticated app bootstraps. Seeding after the
 * app is mounted and then reloading races the first SSE baseline: the server
 * can replace the just-written local day before Mix Plan renders it.
 */
type SeedLiveRun = {
  runId: string;
  brand: string;
  ingredient: string;
  runOz: number;
  casesNeeded: number;
  pizzasPerCase: number;
  casesPerLayer: number;
};

async function seedLiveRunsBeforeAppLoad(
  page: Page,
  seeds: SeedLiveRun[],
  currentIndex = 0,
): Promise<void> {
  await page.addInitScript(({ seeds: initSeeds, currentIndex: initCurrentIndex }) => {
    localStorage.setItem("run-calc-day", JSON.stringify({
      runs: initSeeds.map((seed) => ({
        id: seed.runId,
        brand: seed.brand,
        flavor: "",
        seeded: false,
      })),
      currentIndex: initCurrentIndex,
      date: new Date().toISOString().slice(0, 10),
      // Keep a test-local seed ahead of any blank baseline left by a prior
      // authenticated startup. The run is intentionally not a pristine seed,
      // so same-day sync still merges it additively.
      // Today's resetAt is also the server's auth boundary. Keep this
      // same-day fixture at the stable baseline instead of manufacturing a
      // future reset that can invalidate the account's just-issued session.
      resetAt: 0,
      substitutions: [],
      substitutionLog: [],
      stagedItems: {},
      prepPhase: {
        prepStartedAt: null,
        prepBatchesDough: 0,
        prepBatchesSauce: 0,
        prepCarriedOver: false,
      },
    }));
    const updated = (() => {
      try {
        return JSON.parse(localStorage.getItem("run-calc-runvalues-updated") ?? "{}");
      } catch {
        return {};
      }
    })();
    for (const seed of initSeeds) {
      localStorage.setItem(`run-calc-run-${seed.runId}`, JSON.stringify({
        pep1Type: seed.ingredient,
        pep1OzPerPizza: seed.runOz,
        casesNeeded: seed.casesNeeded,
        pizzasPerCase: seed.pizzasPerCase,
        casesPerLayer: seed.casesPerLayer,
      }));
      updated[seed.runId] = Date.now() + 60_000;
    }
    localStorage.setItem("run-calc-runvalues-updated", JSON.stringify(updated));
  }, { seeds, currentIndex });
}

async function seedLiveRunBeforeAppLoad(
  page: Page,
  opts: SeedLiveRun,
): Promise<void> {
  await seedLiveRunsBeforeAppLoad(page, [opts]);
}

/**
 * Direct localStorage fixture edits happen after the app has already written
 * the authenticated user's blank baseline to the shared day row. Stamp those
 * edits before reloading so sync LWW keeps the fixture instead of restoring
 * the blank remote run.
 */
async function stampLocalFixtureForReload(page: Page): Promise<void> {
  const fixture = await page.evaluate(() => {
    const keys = Object.keys(localStorage).filter((key) =>
      key === "run-calc-day" ||
      key === "run-calc-runvalues-updated" ||
      key.startsWith("run-calc-run-"),
    );
    const saved = Object.fromEntries(keys.map((key) => [key, localStorage.getItem(key)]));
    const now = Date.now() + 60_000;
    try {
      const rawDay = localStorage.getItem("run-calc-day");
      const day = rawDay
        ? JSON.parse(rawDay) as { runs?: Array<{ id: string; metaUpdatedAt?: number }> }
        : {};
      if (Array.isArray(day.runs)) {
        day.runs = day.runs.map((run) => ({ ...run, metaUpdatedAt: now }));
        // resetAt is the server's daily auth boundary, not a generic LWW
        // freshness stamp. Today's fixture must never advance it.
        day.resetAt = typeof day.resetAt === "number" ? day.resetAt : 0;
        localStorage.setItem("run-calc-day", JSON.stringify(day));
        const updated = JSON.parse(localStorage.getItem("run-calc-runvalues-updated") ?? "{}") as Record<string, number>;
        for (const run of day.runs) updated[run.id] = now;
        localStorage.setItem("run-calc-runvalues-updated", JSON.stringify(updated));
      }
    } catch {}
    return Object.fromEntries(
      keys.map((key) => [key, localStorage.getItem(key)]),
    );
  });
  // The server-authoritative Mix Plan endpoint reads the canonical daily
  // snapshot, not the browser's localStorage. Persist the same stamped fixture
  // before a reload or a live Mixes assertion can ask for a fresh snapshot.
  await dbSeedCanonicalDayFromPage(page);
  await page.addInitScript((saved) => {
    // Seed before React/auth/sync boot. Startup may reconcile and clear an
    // authenticated blank baseline before a normal evaluate() can win.
    const now = Date.now() + 60_000;
    try {
      for (const [key, value] of Object.entries(saved)) {
        if (value !== null) localStorage.setItem(key, value);
      }
      const rawDay = localStorage.getItem("run-calc-day");
      const day = rawDay
        ? JSON.parse(rawDay) as { runs?: Array<{ id: string; metaUpdatedAt?: number }> }
        : {};
      if (Array.isArray(day.runs)) {
        day.runs = day.runs.map((run) => ({ ...run, metaUpdatedAt: now }));
        // resetAt is the server's daily auth boundary, not a generic LWW
        // freshness stamp. Today's fixture must never advance it; the
        // per-run meta/value stamps above are sufficient to win the merge.
        day.resetAt = typeof day.resetAt === "number" ? day.resetAt : 0;
        localStorage.setItem("run-calc-day", JSON.stringify(day));
        const updated = JSON.parse(localStorage.getItem("run-calc-runvalues-updated") ?? "{}") as Record<string, number>;
        for (const run of day.runs) updated[run.id] = now;
        localStorage.setItem("run-calc-runvalues-updated", JSON.stringify(updated));
      }
    } catch {}
  }, fixture);
}

async function waitForLocalRunEnded(page: Page, runId: string): Promise<void> {
  await expect.poll(
    () => page.evaluate((id) => {
      const day = JSON.parse(localStorage.getItem("run-calc-day") ?? "{}") as {
        runs?: Array<{ id?: string; endedAt?: number }>;
      };
      return day.runs?.find((run) => run.id === id)?.endedAt ?? null;
    }, runId),
    { timeout: 15_000 },
  ).toBeTruthy();
}

async function waitForLocalRunStarted(page: Page, runId: string): Promise<void> {
  await expect.poll(
    () => page.evaluate((id) => {
      const day = JSON.parse(localStorage.getItem("run-calc-day") ?? "{}") as {
        runs?: Array<{ id?: string; startedAt?: number; endedAt?: number }>;
      };
      const run = day.runs?.find((candidate) => candidate.id === id);
      return run && run.startedAt && !run.endedAt ? run.startedAt : null;
    }, runId),
    { timeout: 15_000 },
  ).toBeTruthy();
}

async function waitForCurrentRun(page: Page, runId: string): Promise<void> {
  await expect.poll(
    () => page.evaluate((id) => {
      const day = JSON.parse(localStorage.getItem("run-calc-day") ?? "{}") as {
        currentIndex?: number;
        runs?: Array<{ id?: string }>;
      };
      return day.runs?.[day.currentIndex ?? 0]?.id ?? null;
    }, runId),
    { timeout: 15_000 },
  ).toBe(runId);
}

async function waitForCanonicalRunField(
  runId: string,
  field: "startedAt" | "endedAt",
): Promise<void> {
  await expect.poll(async () => {
    const result = await db.query<{ data: { dayState?: { runs?: Array<{ id?: string; startedAt?: number; endedAt?: number }> } } }>(
      "SELECT data FROM daily_sync WHERE date = $1 AND scope = 'live'",
      [todayStr()],
    );
    const runs = result.rows[0]?.data?.dayState?.runs ?? [];
    return Boolean(runs.find((run) => run.id === runId)?.[field]);
  }, { timeout: 20_000 }).toBeTruthy();
}

async function dbCreateMix(
  db: Client,
  opts: {
    id: string;
    name: string;
    brand?: string;
    isPrep?: boolean;
    component: string;
    perPizza?: number;
    components?: Array<{ ingredient: string; perPizza: number }>;
    batchSize?: number;
    amountAlreadyMade?: number;
    daysEarly?: number;
  },
): Promise<void> {
  const components = JSON.stringify(
    opts.components ?? [{ ingredient: opts.component, perPizza: opts.perPizza ?? 2.0 }],
  );
  await db.query(
    `INSERT INTO mixes
       (id, scope, name, brand, flavor, batch_size, days_early, notes,
        amount_already_made, components, is_prep, enabled, created_at, updated_at)
     VALUES ($1, 'live', $2, $3, '', $4, $8, '', $7, $5::jsonb, $6, true, NOW(), NOW())
     ON CONFLICT (id, scope) DO UPDATE
       SET name=$2, brand=$3, batch_size=$4, components=$5::jsonb,
           is_prep=$6, amount_already_made=$7, days_early=$8, updated_at=NOW()`,
    [
      opts.id,
      opts.name,
      opts.brand ?? "",
      opts.batchSize ?? 0,
      components,
      opts.isPrep ?? false,
      opts.amountAlreadyMade ?? 0,
      opts.daysEarly ?? 0,
    ],
  );
}

async function dbSeedProfile(
  db: Client,
  opts: {
    brand: string;
    flavor: string;
    ingredient: string;
    runOz: number;
    pizzasPerCase: number;
  },
): Promise<void> {
  const key = `${opts.brand.toLowerCase().trim()}__${opts.flavor.toLowerCase().trim()}`;
  await db.query(
    `INSERT INTO brand_profiles
       (key, scope, brand, flavor, values, crust_values, updated_at_ms, created_at)
     VALUES ($1, 'live', $2, $3, $4::jsonb, '{}'::jsonb, $5, NOW())
     ON CONFLICT (key, scope) DO UPDATE
       SET brand = EXCLUDED.brand,
           flavor = EXCLUDED.flavor,
           values = EXCLUDED.values,
           updated_at_ms = EXCLUDED.updated_at_ms`,
    [
      key,
      opts.brand,
      opts.flavor,
      JSON.stringify({
        pep1Type: opts.ingredient,
        pep1OzPerPizza: opts.runOz,
        pizzasPerCase: opts.pizzasPerCase,
      }),
      Date.now(),
    ],
  );
}

/**
 * Give the server-authoritative Mix Plan endpoint a complete baseline for the
 * browser fixture. New accounts normally begin with a partial sync, which is
 * intentionally not materialized when no canonical daily row exists. Without
 * this baseline, tests that edit localStorage and reload can only exercise the
 * offline plan even though the browser is online.
 */
async function dbSeedCanonicalDayFromPage(page: Page): Promise<void> {
  const fixture = await page.evaluate(() => {
    const rawDay = localStorage.getItem("run-calc-day");
    const dayState = rawDay ? JSON.parse(rawDay) : { runs: [] };
    const runValues = Object.fromEntries(
      (Array.isArray(dayState.runs) ? dayState.runs : []).map((run: { id?: string }) => {
        if (!run.id) return [String(run.id ?? ""), {}];
        try {
          return [run.id, JSON.parse(localStorage.getItem(`run-calc-run-${run.id}`) ?? "{}")];
        } catch {
          return [run.id, {}];
        }
      }).filter(([id]) => Boolean(id)),
    );
    return { dayState, runValues };
  });
  await db.query(
    `INSERT INTO daily_sync (date, scope, data, updated_at)
     VALUES ($1, 'live', $2::jsonb, NOW())
     ON CONFLICT (date, scope) DO UPDATE
       SET data = $2::jsonb, updated_at = NOW()`,
    [
      todayStr(),
      JSON.stringify({
        ...fixture,
        completeness: "complete",
        syncVersion: 1,
      }),
    ],
  );
}

async function seedLiveRunsAfterAppLoad(
  page: Page,
  seeds: SeedLiveRun[],
  currentIndex = 0,
): Promise<void> {
  await page.evaluate(({ seeds: initSeeds, currentIndex: initCurrentIndex }) => {
    localStorage.setItem("run-calc-day", JSON.stringify({
      runs: initSeeds.map((seed) => ({
        id: seed.runId,
        brand: seed.brand,
        flavor: "",
        seeded: false,
      })),
      currentIndex: initCurrentIndex,
      date: new Date().toISOString().slice(0, 10),
      resetAt: 0,
      substitutions: [],
      substitutionLog: [],
      stagedItems: {},
      prepPhase: {
        prepStartedAt: null,
        prepBatchesDough: 0,
        prepBatchesSauce: 0,
        prepCarriedOver: false,
      },
    }));
    const updated: Record<string, number> = {};
    for (const seed of initSeeds) {
      localStorage.setItem(`run-calc-run-${seed.runId}`, JSON.stringify({
        pep1Type: seed.ingredient,
        pep1OzPerPizza: seed.runOz,
        casesNeeded: seed.casesNeeded,
        pizzasPerCase: seed.pizzasPerCase,
        casesPerLayer: seed.casesPerLayer,
      }));
      updated[seed.runId] = Date.now() + 60_000;
    }
    localStorage.setItem("run-calc-runvalues-updated", JSON.stringify(updated));
  }, { seeds, currentIndex });
  await dbSeedCanonicalDayFromPage(page);
  await stampLocalFixtureForReload(page);
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
  await closeOnboardingIfVisible(page);
}

/** Format a Date as YYYY-MM-DD using the local calendar (matches app ?today= keying). */
function localDateStr(d: Date): string {
  return [
    d.getFullYear(),
    String(d.getMonth() + 1).padStart(2, "0"),
    String(d.getDate()).padStart(2, "0"),
  ].join("-");
}

function todayStr(): string {
  return localDateStr(new Date());
}

// ── DB lifecycle ──────────────────────────────────────────────────────────────

let db: Client;

async function makeTestUserManager(username: string): Promise<void> {
  await db.query(
    `UPDATE user_roles
        SET role = 'manager', updated_at = NOW()
      WHERE user_id = (SELECT id FROM users WHERE username = $1)`,
    [username],
  );
}

test.beforeAll(async () => {
  requireIsolatedTestDatabase("Mix Plan E2E");
  db = new Client({ connectionString: process.env.DATABASE_URL });
  await db.connect();
});

test.afterAll(async () => {
  await db.end();
});

test.beforeEach(async () => {
  // Each browser test signs up a fresh user, but today's live day-state is
  // factory-scoped and is written back by the app during startup and edits.
  // Clearing it per test prevents a previous test's runs (including ended
  // runs) from changing which products qualify for the next test's Mix Plan.
  // Future scheduled rows are deliberately left alone; tests that create one
  // snapshot and restore their own date-scoped fixture.
  await db.query("DELETE FROM daily_sync WHERE date = $1", [todayStr()]);
});

// ── tests ─────────────────────────────────────────────────────────────────────

test.describe("Mix Plan — prep card suppression and ended-run removal", () => {
  /**
   * Test (a): Prep mix card is absent when no active run lists its component.
   */
  test("prep mix card is absent when no active run lists its component ingredient", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-mix-${suffix}`;
    const mixName = `HerbPrepMix ${suffix}`;
    const ingredient = `HerbIngredient_${suffix}`;

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: false,
        component: ingredient,
        perPizza: 1.5,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      await expect(page.getByText(ingredient, { exact: true })).toHaveCount(0, {
        timeout: 5_000,
      });
      await expect(page.getByText(mixName, { exact: false })).toHaveCount(0, {
        timeout: 3_000,
      });
      // Other suites may leave unrelated factory-wide prep recipes in the
      // shared master-data pool. The invariant here is that this exact mix and
      // component are absent without a qualifying active run.
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (c): Ending ONE run in a two-run shift keeps the OTHER run's mix card.
   *
   * Mechanism: liveRunsForMixes (home.tsx ~14462) filters dayState.runs by
   * `r.brand && !r.endedAt`. Once STOP RUN sets r.endedAt on run-1, run-2
   * (still active) keeps its mix card visible.
   */
  test("ending one run keeps the other run's mix card visible in a multi-run shift", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId1 = `run-mix-a-${suffix}`;
    const mixId2 = `run-mix-b-${suffix}`;
    const mixName1 = `RunMixA ${suffix}`;
    const mixName2 = `RunMixB ${suffix}`;
    const component1 = `CompA_${suffix}`;
    const component2 = `CompB_${suffix}`;
    const brand1 = `BrandA_${suffix}`;
    const brand2 = `BrandB_${suffix}`;
    const today = todayStr();
    const runId1 = `run-a-${suffix}`;
    const runId2 = `run-b-${suffix}`;

    try {
      // Create two mixes — one per brand — so each run's active status drives its
      // own mix card independently.
      await dbCreateMix(db, {
        id: mixId1,
        name: mixName1,
        brand: brand1,
        isPrep: false,
        component: component1,
        perPizza: 2.0,
        batchSize: 10,
      });
      await dbCreateMix(db, {
        id: mixId2,
        name: mixName2,
        brand: brand2,
        isPrep: false,
        component: component2,
        perPizza: 2.0,
        batchSize: 10,
      });

      // Seed both branded runs and their durable values before app hydration.
      // signUpAndDismissOnboarding materializes the same fixture into the
      // canonical daily row before the post-auth reload.
      await seedLiveRunsBeforeAppLoad(page, [
        {
          runId: runId1,
          brand: brand1,
          ingredient: component1,
          runOz: 2,
          casesNeeded: 1,
          pizzasPerCase: 8,
          casesPerLayer: 0,
        },
        {
          runId: runId2,
          brand: brand2,
          ingredient: component2,
          runOz: 2,
          casesNeeded: 1,
          pizzasPerCase: 8,
          casesPerLayer: 0,
        },
      ], 1);
      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      // The auth form transitions to "/" without a document reload. Re-enter
      // the app route so the init-script seed is read before React hydration.
      await page.goto("/", { waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });

      // Both mix cards must appear on the Mixes tab
      await goToMixes(page);
      await page.waitForTimeout(500);
      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 20_000 });
      await expect(todayCard.getByText(mixName1, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName2, { exact: false })).toBeVisible({ timeout: 5_000 });

      // Switch to run 1 via Prev and start it
      await page.locator('[data-testid="tab-run"]').click();
      const prevBtn = page.getByRole("button", { name: /prev/i });
      await prevBtn.waitFor({ state: "visible", timeout: 8_000 });
      await prevBtn.click();
      await waitForCurrentRun(page, runId1);

      const startBtn = page.locator('[data-testid="button-start-run"]');
      await startBtn.waitFor({ state: "visible", timeout: 8_000 });
      await startBtn.click();

      // Stop run 1
      const stopBtn = page.getByRole("button", { name: /stop run/i });
      await stopBtn.waitFor({ state: "visible", timeout: 10_000 });
      // Starting a run first queues a canonical write. Wait for that write to
      // settle before stopping; otherwise endRun can correctly defer behind
      // the foreground sync barrier and the test may navigate away while the
      // stop is still only queued.
      await expect(page.getByText("Synchronized", { exact: true })).toBeVisible({
        timeout: 15_000,
      });
      await stopBtn.click();

      // endRun() advances to run 2, so the start control is the visible
      // transition signal. Also verify the actual persisted local lifecycle
      // field before checking the server-backed Mix Plan.
      await expect(startBtn).toBeVisible({ timeout: 15_000 });
      await expect.poll(
        () => page.evaluate((id) => {
          const day = JSON.parse(localStorage.getItem("run-calc-day") ?? "{}") as {
            runs?: Array<{ id?: string; endedAt?: number }>;
          };
          return day.runs?.find((run) => run.id === id)?.endedAt ?? null;
        }, runId1),
        { timeout: 15_000 },
      ).toBeTruthy();

      // Verify run-2's mix is still visible; run-1's mix is gone
      await goToMixes(page);
      await page.waitForTimeout(500);

      // The date-group card must still be present — run 2 is still active.
      await expect(
        page.locator(`[data-testid="mix-plan-${today}"]`),
      ).toBeVisible({ timeout: 5_000 });

      // Run-1 ended → its brand is excluded from liveRunsForMixes → mix gone.
      await expect(
        page.getByText(mixName1, { exact: false }),
      ).toHaveCount(0, { timeout: 5_000 });

      // Run-2 is still active → its mix must remain visible.
      await expect(
        page.locator(`[data-testid="mix-plan-${today}"]`).getByText(mixName2, {
          exact: false,
        }),
      ).toBeVisible({ timeout: 5_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId1]).catch(() => {});
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId2]).catch(() => {});
      await db.query("DELETE FROM daily_sync WHERE date = $1 AND scope = 'live'", [today]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (b): Mix card disappears from the plan after the run is marked ended.
   *
   * Mechanism: liveRunsForMixes (home.tsx ~14462) filters dayState.runs by
   * `r.brand && !r.endedAt`. Once STOP RUN sets r.endedAt, the run is excluded
   * and buildMixPlan returns [] — the plan collapses to empty.
   */
  test("mix card disappears from the plan after the run is marked ended", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `run-mix-${suffix}`;
    const mixName = `RunMix ${suffix}`;
    const component = `Component_${suffix}`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    try {
      // Create the mix with the SAME brand that we'll set on the run form.
      // buildMixPlan matches on exact productKey(brand, flavor), so brand must
      // agree — an empty-brand mix only matches empty-brand runs (which are
      // filtered out of liveRunsForMixes since they have no brand set).
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        brand,
        isPrep: false,
        component,
        perPizza: 2.0,
        batchSize: 10,
      });

      // Sign up via browser and dismiss the onboarding dialog.
      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      // Brief pause for startup async effects (useMixes fetch, etc.).
      await page.waitForTimeout(1_000);

      // Set the brand on the run form.
      // A run with r.brand set and !r.endedAt is included in liveRunsForMixes.
      // The blank seeded placeholder run has no brand, so we must set one.
      await page.locator('[data-testid="tab-run"]').click();
      const brandInput = page.locator('input[placeholder="Brand…"]').first();
      await brandInput.waitFor({ state: "visible", timeout: 10_000 });
      await brandInput.click();
      await brandInput.fill(brand);
      await brandInput.press("Enter");
      await page.waitForTimeout(800);

      await goToMixes(page);
      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 20_000 }).catch(async () => {
        await page.reload({ waitUntil: "domcontentloaded" });
        await page.locator('[data-testid="tab-run"]')
          .waitFor({ state: "attached", timeout: 25_000 });
        await dismissOnboarding(page);
        await goToMixes(page);
        await todayCard.waitFor({ state: "visible", timeout: 20_000 });
      });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible();

      await page.locator('[data-testid="tab-run"]').click();
      const startBtn = page.locator('[data-testid="button-start-run"]');
      await startBtn.waitFor({ state: "visible", timeout: 8_000 });
      await startBtn.click();
      await waitForCanonicalRunField(
        (await page.evaluate(() => {
          const day = JSON.parse(localStorage.getItem("run-calc-day") ?? "{}") as {
            runs?: Array<{ id?: string }>;
          };
          return day.runs?.[0]?.id ?? "";
        })),
        "startedAt",
      );

      const stopBtn = page.getByRole("button", { name: /stop run/i });
      await stopBtn.waitFor({ state: "visible", timeout: 10_000 });
      await stopBtn.click();
      const runId = await page.evaluate(() => {
        const day = JSON.parse(localStorage.getItem("run-calc-day") ?? "{}") as {
          runs?: Array<{ id?: string }>;
        };
        return day.runs?.[0]?.id ?? "";
      });
      await waitForLocalRunEnded(page, runId);
      await waitForCanonicalRunField(runId, "endedAt");

      await goToMixes(page);
      await expect(
        page.locator(`[data-testid="mix-plan-${today}"]`),
      ).toHaveCount(0, { timeout: 5_000 });
      await expect(
        page.locator('[data-testid="mix-plan-empty"]'),
      ).toBeVisible({ timeout: 5_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  test("prep mix card shows the ordinary ingredient total", async ({
    page,
    playwright,
  }) => {
    const suffix = uid();
    const mixId = `prep-normal-${suffix}`;
    const mixName = `NormalPrepMix ${suffix}`;
    const ingredient = `TestHerb_${suffix}`;
    const brand = `NormalBrand_${suffix}`;
    const today = todayStr();
    const runId = `normal-run-${suffix}`;
    const fixtures = await AuthorizedBrowserFixtures.create(
      playwright,
      API_BASE,
      SIGNUP_CODE,
    );
    try {
      const account = await fixtures.createAccount({
        username: `user_${suffix}`,
        password: "TestPass123!",
        capabilities: DEFAULT_MANAGER_CAPABILITIES,
        onboardingSeen: true,
      });
      await fixtures.seedMix(account, {
        id: mixId,
        name: mixName,
        isPrep: true,
        components: [{ ingredient, perPizza: 0.5 }],
      });
      await fixtures.removeTodaySync([today]);
      await fixtures.seedTodaySync({
        token: account.token,
            senderId: `normal-sender-${suffix}`,
        date: today,
        payload: {
          dayState: {
            date: today,
            runs: [{ id: runId, brand, flavor: "", seeded: false }],
            currentIndex: 0,
            resetAt: 0,
            substitutions: [],
            substitutionLog: [],
            stagedItems: {},
          },
          runValues: {
            [runId]: {
              casesNeeded: 1,
              pizzasPerCase: 8,
              casesPerLayer: 0,
              pep1Type: ingredient,
              pep1OzPerPizza: 2,
            },
          },
          runValuesUpdatedAt: { [runId]: Date.now() },
          packagingProgress: {},
        },
      });

      await page.context().addCookies([{
        name: "rc_auth",
        value: account.token,
        url: API_BASE,
      }]);
      await page.goto("/", { waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({
        state: "attached",
        timeout: 25_000,
      });

      await goToMixes(page);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 20_000 });
      await expect(todayCard.getByText(mixName, { exact: true })).toBeVisible();
      await expect(todayCard.getByText(ingredient, { exact: true })).toBeVisible();

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(ingredient, { exact: true }) })
        .last();
      await expect(ingredientRow).toContainText("1.00");
    } finally {
      await fixtures.cleanup();
    }
  });

  /**
   * Test (d): Prep mix card shows correct "Pull For Prep" quantities.
   *
   * amountAlreadyMade = 0 → pull = component lbs.
   * Uses run-profile oz (2.0) not mix-card fallback oz (0.5).
   * expectedPullLbs = (2.0/16) × 800 = 100.00
   */
  test("prep mix card shows correct pull quantities when a run uses its ingredient", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-pull-${suffix}`;
    const mixName = `PullPrepMix ${suffix}`;
    const ingredient = `TestHerb_${suffix}`;

    const MIX_CARD_OZ = 0.5;
    const RUN_OZ = 2.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const CASES_PER_LAYER = 0;
    const totalPizzasForSauce = CASES_NEEDED * PIZZAS_PER_CASE + CASES_PER_LAYER * PIZZAS_PER_CASE;
    const expectedPullLbs = (RUN_OZ / 16) * totalPizzasForSauce; // 100.00

    const brand = `Brand_${suffix}`;
    const today = todayStr();

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: MIX_CARD_OZ,
      });

      await seedLiveRunBeforeAppLoad(page, {
        runId: `prep-pull-run-${suffix}`,
        brand,
        ingredient,
        runOz: RUN_OZ,
        casesNeeded: CASES_NEEDED,
        pizzasPerCase: PIZZAS_PER_CASE,
        casesPerLayer: CASES_PER_LAYER,
      });
      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      // The auth form transitions to "/" without a document reload. Re-enter
      // the app route so the init-script seed is read before React hydration.
      await page.goto("/", { waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 20_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(ingredient, { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(ingredient, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();

      const expectedStr = expectedPullLbs.toFixed(2); // "100.00"
      const wrongFallbackStr = ((MIX_CARD_OZ / 16) * totalPizzasForSauce).toFixed(2); // "25.00"

      expect(rowText).toContain(expectedStr);
      expect(rowText).not.toContain(wrongFallbackStr);
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (d2): Pull For Prep updates when a second run is added while Mixes is
   * already open.
   *
   * The first run contributes 100 lbs. The second run is created through the
   * Run tab after the Mixes plan is visible and contributes another 25 lbs.
   * Returning to Mixes must use the new live day-state run without a reload.
   */
  test("Pull For Prep includes a second run added while Mixes is open", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-live-add-${suffix}`;
    const mixName = `LiveAddPrepMix ${suffix}`;
    const ingredient = `LiveAddHerb_${suffix}`;
    const brand1 = `LiveAddBrandA_${suffix}`;
    const brand2 = `LiveAddBrandB_${suffix}`;
    const today = todayStr();

    const firstPullLbs = (2 / 16) * 100 * 8; // 100.00
    const secondPullLbs = (1 / 16) * 25 * 8; // 12.50
    const combinedPullLbs = firstPullLbs + secondPullLbs; // 112.50

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: 0.5,
      });

      await seedLiveRunBeforeAppLoad(page, {
        runId: `prep-live-add-run-${suffix}`,
        brand: brand1,
        ingredient,
        runOz: 2,
        casesNeeded: 100,
        pizzasPerCase: 8,
        casesPerLayer: 0,
      });
      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await makeTestUserManager(username);
      await page.goto("/", { waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 20_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible();
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible();
      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(ingredient, { exact: true }) })
        .last();
      await expect(ingredientRow).toContainText(firstPullLbs.toFixed(2));

      // Add and configure run 2 from the Run tab while preserving the mounted
      // page (no reload between the two Mixes assertions).
      await page.locator('[data-testid="tab-run"]').click();
      const newRunBtn = page.getByRole("button", { name: /new run/i });
      await newRunBtn.waitFor({ state: "visible", timeout: 8_000 });
      await newRunBtn.click();
      await page.waitForTimeout(600);

      const brandInput = page.locator('input[placeholder="Brand…"]').first();
      await brandInput.waitFor({ state: "visible", timeout: 10_000 });
      await brandInput.click();
      await brandInput.fill(brand2);
      await brandInput.press("Enter");

      // Leave the new run first: switching away saves the live form, so doing
      // this in the opposite order would overwrite the direct fixture values
      // with the compact form's defaults.
      await page.getByRole("button", { name: /prev/i }).click();
      await page.waitForTimeout(300);

      // The Run tab's compact view does not render the applicator editor.
      // Persist the new run's ingredient fields, then switch back so the
      // normal run-switch path hydrates them into the open form.
      await page.evaluate(({ ingredient }) => {
        const dayKey = "run-calc-day";
        const rawDay = localStorage.getItem(dayKey);
        if (!rawDay) return;
        const day = JSON.parse(rawDay) as { runs?: Array<{ id: string }> };
        const run = day.runs?.[day.runs.length - 1];
        if (!run) return;
        localStorage.setItem(`run-calc-run-${run.id}`, JSON.stringify({
          pep1Type: ingredient,
          pep1OzPerPizza: 1,
          casesNeeded: 25,
          pizzasPerCase: 8,
          casesPerLayer: 0,
        }));
      }, { ingredient });
      await stampLocalFixtureForReload(page);
      await page.getByRole("button", { name: /next/i }).click();
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(ingredientRow).toContainText(combinedPullLbs.toFixed(2), {
        timeout: 5_000,
      });
      await expect(ingredientRow).not.toContainText(firstPullLbs.toFixed(2));
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (e): Per-run breakdown is correct when two brands share an ingredient.
   *
   * amountAlreadyMade = 0 → pull = contrib1 + contrib2 = 137.50
   * Run1: (2.0/16)×800 = 100.00, Run2: (1.5/16)×400 = 37.50
   */
  test("prep mix card shows correct per-run breakdown when two brands share an ingredient", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-breakdown-${suffix}`;
    const mixName = `BreakdownPrepMix ${suffix}`;
    const ingredient = `SharedHerb_${suffix}`;

    const brand1 = `Alpha_${suffix}`;
    const OZ1 = 2.0;
    const CASES1 = 100;
    const PPC = 8;
    const brand2 = `Beta_${suffix}`;
    const OZ2 = 1.5;
    const CASES2 = 50;

    const pizzas1 = CASES1 * PPC; // 800
    const pizzas2 = CASES2 * PPC; // 400
    const contrib1Lbs = (OZ1 / 16) * pizzas1; // 100.00
    const contrib2Lbs = (OZ2 / 16) * pizzas2; //  37.50
    const pullLbs = contrib1Lbs + contrib2Lbs;  // 137.50

    const today = todayStr();

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: 0.1,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await makeTestUserManager(username);

      await page.evaluate(
        ({ brand1, brand2, ingredient, oz1, oz2, cases1, cases2, ppc }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;

          day.runs[0].brand = brand1;
          const runId1 = day.runs[0].id;
          const existing1 = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId1)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId1), JSON.stringify({
            ...existing1, pep1Type: ingredient, pep1OzPerPizza: oz1,
            casesNeeded: cases1, pizzasPerCase: ppc, casesPerLayer: 0,
          }));

          const runId2 = `e2e-run2-${Math.random().toString(36).slice(2, 9)}`;
          day.runs.push({ id: runId2, brand: brand2 });
          localStorage.setItem(RUN_KEY(runId2), JSON.stringify({
            pep1Type: ingredient, pep1OzPerPizza: oz2,
            casesNeeded: cases2, pizzasPerCase: ppc, casesPerLayer: 0,
          }));
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
        },
        { brand1, brand2, ingredient, oz1: OZ1, oz2: OZ2, cases1: CASES1, cases2: CASES2, ppc: PPC },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await dismissOnboarding(page);
      await page.locator('button[title="More"]').waitFor({ state: "visible", timeout: 15_000 });
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });

      const breakdownBtn = todayCard.getByRole("button", { name: /show run breakdown \(2 runs\)/i });
      await expect(breakdownBtn).toBeVisible({ timeout: 5_000 });
      await breakdownBtn.click();

      await expect(
        todayCard.getByRole("button", { name: /hide run breakdown \(2 runs\)/i }),
      ).toBeVisible({ timeout: 3_000 });

      const contrib1Str = contrib1Lbs.toFixed(2); // "100.00"
      const brand1Row = todayCard.locator("div", { has: page.getByText(brand1, { exact: false }) }).last();
      expect(await brand1Row.innerText()).toContain(contrib1Str);

      const contrib2Str = contrib2Lbs.toFixed(2); // "37.50"
      const brand2Row = todayCard.locator("div", { has: page.getByText(brand2, { exact: false }) }).last();
      expect(await brand2Row.innerText()).toContain(contrib2Str);

      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      const pullStr = pullLbs.toFixed(2); // "137.50"
      const ingredientRow = todayCard.locator("div", { has: page.getByText(ingredient, { exact: true }) }).last();
      expect(await ingredientRow.innerText()).toContain(pullStr);
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (f): Pull For Prep is reduced proportionally when some of the mix is
   * already made (amountAlreadyMade = 50, single run).
   *
   * componentLbs = (2.0/16)×800 = 100.00
   * totalLbs     = 100×1.15+20  = 135.00
   * remainingLbs = 135-50       =  85.00
   * pull         = 100×85/135   ≈  62.96
   */
  test("Pull For Prep is reduced proportionally when some of the mix is already made", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-partial-${suffix}`;
    const mixName = `PartialPrepMix ${suffix}`;
    const ingredient = `PartialHerb_${suffix}`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 2.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 800

    const MIX_WASTE_FACTOR = 0.15;
    const STARTUP_LBS = 20;
    const AMOUNT_ALREADY_MADE = 50;
    const componentLbs = (RUN_OZ / 16) * totalPizzas;           // 100.00
    const totalLbs = componentLbs * (1 + MIX_WASTE_FACTOR) + STARTUP_LBS; // 135.00
    const remainingLbs = totalLbs - AMOUNT_ALREADY_MADE;          //  85.00
    const expectedPullLbs = componentLbs * remainingLbs / totalLbs; // ≈62.96
    const expectedStr = expectedPullLbs.toFixed(2);               // "62.96"
    const fullStr = componentLbs.toFixed(2);                       // "100.00"

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: RUN_OZ,
        amountAlreadyMade: AMOUNT_ALREADY_MADE,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await makeTestUserManager(username);

      await page.evaluate(
        ({ brand, ingredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: ingredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, ingredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await dismissOnboarding(page);
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(ingredient, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();

      expect(rowText).toContain(expectedStr);
      expect(rowText).not.toContain(fullStr);
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (g): Pull For Prep shows 0.00 lbs when the mix is fully covered
   * (amountAlreadyMade >= totalLbs). Card still renders so staff can confirm.
   *
   * remainingLbs = max(0, 135-200) = 0 → pull = 0.00
   */
  test("Pull For Prep shows 0.00 lbs when the mix is fully covered by amountAlreadyMade", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-full-${suffix}`;
    const mixName = `FullCoveredPrepMix ${suffix}`;
    const ingredient = `CoveredHerb_${suffix}`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 2.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const AMOUNT_ALREADY_MADE = 200;

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: RUN_OZ,
        amountAlreadyMade: AMOUNT_ALREADY_MADE,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, ingredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: ingredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, ingredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await dismissOnboarding(page);
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(ingredient, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();
      expect(rowText).toContain("0.00");
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (i): Badge updates live when the "Already made" input is edited.
   *
   * Mechanism: onBlur → saveMixes → onSaved → cycleCountQc.setQueryData →
   * buildMixPlan re-runs → Pull For Prep and badge update without page reload.
   */
  test("'need X lbs' badge updates immediately when 'already made' is edited", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `badge-live-${suffix}`;
    const mixName = `BadgeLivePrepMix ${suffix}`;
    const ingredient = `BadgeHerb_${suffix}`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 2.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 800
    const MIX_WASTE_FACTOR = 0.15;
    const STARTUP_LBS = 20;
    const componentLbs = (RUN_OZ / 16) * totalPizzas;                     // 100.00
    const totalLbs = componentLbs * (1 + MIX_WASTE_FACTOR) + STARTUP_LBS; // 135.00

    const EDIT_AMOUNT = 50;
    const remainingAfterEdit = totalLbs - EDIT_AMOUNT;                     //  85.00
    const remainingStr = remainingAfterEdit.toFixed(2);                    // "85.00"

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: RUN_OZ,
        amountAlreadyMade: 0,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, ingredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: ingredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, ingredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await dismissOnboarding(page);
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });

      // Step 1: badge absent before any edit (remainingLbs == totalLbs)
      await expect(todayCard.getByText(/need .+ lbs/, { exact: false })).toHaveCount(0, { timeout: 3_000 });

      // Step 2: type 50 and blur
      const alreadyMadeInput = todayCard.locator('input[type="number"]').first();
      await alreadyMadeInput.waitFor({ state: "visible", timeout: 5_000 });
      await alreadyMadeInput.click();
      await alreadyMadeInput.fill(String(EDIT_AMOUNT));
      await alreadyMadeInput.blur();
      await page.waitForTimeout(1_500);

      // Step 3: badge shows "need 85.00 lbs"
      await expect(
        todayCard.getByText(`need ${remainingStr} lbs`, { exact: false }),
      ).toBeVisible({ timeout: 5_000 });

      // Step 4: clear back to 0
      await alreadyMadeInput.click();
      await alreadyMadeInput.fill("0");
      await alreadyMadeInput.blur();
      await page.waitForTimeout(1_500);

      // Step 5: badge disappears
      await expect(todayCard.getByText(/need .+ lbs/, { exact: false })).toHaveCount(0, { timeout: 5_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (h): Pull For Prep is scaled proportionally when TWO runs share a prep
   * ingredient and amountAlreadyMade > 0.  — Task #764 target.
   *
   * This is the multi-run analogue of test (f). The PULL FOR PREP total on the
   * ingredient row is scaled by `remainingLbs / totalLbs`, while per-run
   * breakdown rows show each run's FULL unscaled lbs (contrib.totalLbs).
   *
   * Formula (lib/mixes/src/index.ts, computeEntryFromComponentLbs):
   *   contrib1Lbs   = (2.0/16) × 800  = 100.00
   *   contrib2Lbs   = (1.5/16) × 400  =  37.50
   *   componentLbs  = 137.50
   *   totalLbs      = 137.50 × 1.15 + 20  = 178.125
   *   remainingLbs  = 178.125 − 50        = 128.125
   *   pullLbs       = 137.50 × 128.125 / 178.125 ≈ 98.90
   *
   * Breakdown rows must show unscaled 100.00 and 37.50 (NOT the scaled pull).
   */
  test("Pull For Prep is scaled proportionally when two runs share a prep ingredient and some is already made", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-partial-multi-${suffix}`;
    const mixName = `PartialMultiPrepMix ${suffix}`;
    const ingredient = `SharedPartialHerb_${suffix}`;
    const today = todayStr();

    const brand1 = `Alpha_${suffix}`;
    const OZ1 = 2.0;
    const CASES1 = 100;
    const PPC = 8;

    const brand2 = `Beta_${suffix}`;
    const OZ2 = 1.5;
    const CASES2 = 50;

    const pizzas1 = CASES1 * PPC; // 800
    const pizzas2 = CASES2 * PPC; // 400

    const contrib1Lbs = (OZ1 / 16) * pizzas1; // 100.00
    const contrib2Lbs = (OZ2 / 16) * pizzas2; //  37.50
    const contrib1Str = contrib1Lbs.toFixed(2); // "100.00"
    const contrib2Str = contrib2Lbs.toFixed(2); //  "37.50"

    const componentLbs = contrib1Lbs + contrib2Lbs; // 137.50

    const MIX_WASTE_FACTOR = 0.15;
    const STARTUP_LBS = 20;
    const AMOUNT_ALREADY_MADE = 50;
    const totalLbs = componentLbs * (1 + MIX_WASTE_FACTOR) + STARTUP_LBS; // 178.125
    const remainingLbs = totalLbs - AMOUNT_ALREADY_MADE;                   // 128.125

    const pullLbs = componentLbs * remainingLbs / totalLbs; // ≈ 98.90
    const pullStr = pullLbs.toFixed(2); // "98.90"
    const fullStr = componentLbs.toFixed(2); // "137.50"

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: OZ1,
        amountAlreadyMade: AMOUNT_ALREADY_MADE,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand1, brand2, ingredient, oz1, oz2, cases1, cases2, ppc }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;

          day.runs[0].brand = brand1;
          const runId1 = day.runs[0].id;
          const existing1 = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId1)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId1), JSON.stringify({
            ...existing1, pep1Type: ingredient, pep1OzPerPizza: oz1,
            casesNeeded: cases1, pizzasPerCase: ppc, casesPerLayer: 0,
          }));

          const runId2 = `e2e-partial-run2-${Math.random().toString(36).slice(2, 9)}`;
          day.runs.push({ id: runId2, brand: brand2 });
          localStorage.setItem(RUN_KEY(runId2), JSON.stringify({
            pep1Type: ingredient, pep1OzPerPizza: oz2,
            casesNeeded: cases2, pizzasPerCase: ppc, casesPerLayer: 0,
          }));
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
        },
        { brand1, brand2, ingredient, oz1: OZ1, oz2: OZ2, cases1: CASES1, cases2: CASES2, ppc: PPC },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });

      // ── 1. Ingredient row shows SCALED pull (98.90), not full (137.50) ────────
      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(ingredient, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();
      expect(rowText).toContain(pullStr);
      expect(rowText).not.toContain(fullStr);

      // ── 2. Breakdown rows show UNSCALED lbs ────────────────────────────────
      const breakdownBtn = todayCard.getByRole("button", { name: /show run breakdown \(2 runs\)/i });
      await expect(breakdownBtn).toBeVisible({ timeout: 5_000 });
      await breakdownBtn.click();
      await expect(
        todayCard.getByRole("button", { name: /hide run breakdown \(2 runs\)/i }),
      ).toBeVisible({ timeout: 3_000 });

      const brand1Row = todayCard.locator("div", { has: page.getByText(brand1, { exact: false }) }).last();
      expect(await brand1Row.innerText()).toContain(contrib1Str); // "100.00" (unscaled)

      const brand2Row = todayCard.locator("div", { has: page.getByText(brand2, { exact: false }) }).last();
      expect(await brand2Row.innerText()).toContain(contrib2Str); // "37.50" (unscaled)
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (i): Prep mix card appears for a SCHEDULED (future-day) run that lists
   * its ingredient, and is absent when today is selected (no live run uses it).
   *
   * Mechanism:
   *   home.tsx (~14477–14489) reads scheduledDays from the API and, for each
   *   scheduled run, loads the saved profile via loadProfile(brand, flavor).
   *   valsToMixRun() then builds ingredientOzPerPizza from the profile's pep
   *   fields, and buildMixPlan matches prep-mix components against each run's
   *   `ingredients` list. If the profile is missing or ingredient names don't
   *   align, the card is silently absent.
   *
   *   This test exercises that path end-to-end:
   *     1. A prep mix is inserted with a unique ingredient name.
   *     2. A scheduled run for tomorrow is inserted directly into daily_sync
   *        (scope=live) so the startup fetch returns it in scheduledDays.
   *     3. A profile for the brand is injected into localStorage with
   *        pep1Type=ingredient so loadProfile() returns it to valsToMixRun.
   *     4. With make-day = today (default): no live run uses the ingredient →
   *        empty-state is shown.
   *     5. With make-day = tomorrow: the scheduled run matches → group card
   *        appears with "Ingredient Prep", mix name, "Pull For Prep", and the
   *        correct pull lbs derived from the profile oz, not the mix-card fallback.
   *     6. Switching back to today: empty-state is restored.
   *
   * Formula:
   *   expectedPullLbs = (RUN_OZ / 16) × (CASES_NEEDED × PIZZAS_PER_CASE)
   *                   = (2.0 / 16) × 800 = 100.00 lbs
   *   MIX_CARD_OZ (0.5) is the wrong fallback; if the code ignores
   *   ingredientOzPerPizza the result would be 25.00.
   */
  test("prep mix card appears for a scheduled future-day run that lists its ingredient", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `sched-future-${suffix}`;
    const mixName = `FuturePrepMix ${suffix}`;
    const ingredient = `FutureHerb_${suffix}`;
    const brand = `FutureBrand_${suffix}`;
    const flavor = "";

    // MIX_CARD_OZ is the fallback perPizza stored on the mix itself.
    // RUN_OZ is the profile-derived oz/pizza that buildMixPlan should prefer.
    // If the profile lookup is broken the displayed lbs will be 25.00, not 100.00.
    const MIX_CARD_OZ = 0.5;
    const RUN_OZ = 2.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 800
    const expectedPullLbs = (RUN_OZ / 16) * totalPizzas; // 100.00
    const wrongFallbackLbs = (MIX_CARD_OZ / 16) * totalPizzas; // 25.00

    // Tomorrow in YYYY-MM-DD using the shared local-calendar helper — consistent
    // with todayStr() and the app's ?today= keying so both dates are in the same
    // time zone frame and the step-10 "switch back to today" assertion is correct.
    const tomorrowLocal = new Date();
    tomorrowLocal.setDate(tomorrowLocal.getDate() + 1);
    const tomorrowStr = localDateStr(tomorrowLocal);

    const scheduledRunId = `sched-run-${suffix}`;

    // Snapshot the existing daily_sync row (if any) so we can restore it on
    // teardown instead of permanently deleting shared schedule data.
    let preExistingRow: { data: unknown; updated_at: Date } | null = null;

    try {
      // ── Step 1: Insert the prep mix ──────────────────────────────────────────
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: MIX_CARD_OZ,
      });

      // ── Step 2: Snapshot + upsert a scheduled run for tomorrow in daily_sync ──
      // The /sync/scheduled endpoint reads daily_sync WHERE date > today AND
      // scope = 'live'. Read the existing row first so teardown can restore it.
      const existingResult = await db.query<{ data: unknown; updated_at: Date }>(
        `SELECT data, updated_at FROM daily_sync WHERE date = $1 AND scope = 'live'`,
        [tomorrowStr],
      );
      preExistingRow = existingResult.rows.length > 0 ? existingResult.rows[0] : null;

      const scheduledData = {
        dayState: {
          runs: [{ id: scheduledRunId, brand, flavor }],
        },
        runValues: {
          [scheduledRunId]: { casesNeeded: CASES_NEEDED },
        },
      };
      await db.query(
        `INSERT INTO daily_sync (date, scope, data, updated_at)
         VALUES ($1, 'live', $2::jsonb, NOW())
         ON CONFLICT (date, scope) DO UPDATE
           SET data = $2::jsonb, updated_at = NOW()`,
        [tomorrowStr, JSON.stringify(scheduledData)],
      );

      // ── Step 3: Sign up and dismiss onboarding ───────────────────────────────
      // Sign up AFTER the DB row exists so the startup fetch (on app mount) picks
      // up the scheduled run and populates scheduledDays React state.
      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      // Brief pause for startup async effects (useMixes + scheduledDays fetch).
      await page.waitForTimeout(1_000);

      // ── Step 4: Inject the profile into localStorage ─────────────────────────
      // loadProfile(brand, flavor) reads from localStorage key
      // `run-calc-profile-${brand.toLowerCase()}__${flavor.toLowerCase()}`.
      // valsToMixRun maps pep1Type → ingredientOzPerPizza, so the ingredient must
      // appear in pep1Type with pep1OzPerPizza = RUN_OZ. pizzasPerCase comes from
      // the profile (not the scheduled run), so it must be set here too.
      await page.evaluate(
        ({ brand, flavor, ingredient, runOz, pizzasPerCase }) => {
          const profileKey = `run-calc-profile-${brand.toLowerCase().trim()}__${flavor.toLowerCase().trim()}`;
          const existing = (() => {
            try {
              return JSON.parse(localStorage.getItem(profileKey) ?? "{}");
            } catch {
              return {};
            }
          })();
          localStorage.setItem(
            profileKey,
            JSON.stringify({
              ...existing,
              pep1Type: ingredient,
              pep1OzPerPizza: runOz,
              pizzasPerCase,
            }),
          );
        },
        { brand, flavor, ingredient, runOz: RUN_OZ, pizzasPerCase: PIZZAS_PER_CASE },
      );
      await dbSeedProfile(db, {
        brand,
        flavor,
        ingredient,
        runOz: RUN_OZ,
        pizzasPerCase: PIZZAS_PER_CASE,
      });
      await page.reload({ waitUntil: "domcontentloaded" });

      // ── Step 5: Navigate to the Mixes tab ────────────────────────────────────
      await goToMixes(page);
      await page.waitForTimeout(500);

      // ── Step 6: Today (default make-day) shows empty-state ──────────────────
      // The only live run today is the blank seeded placeholder (no brand, no
      // ingredient list), so buildMixPlan returns [] → empty-state is shown.
      await expect(
        page.locator('[data-testid="mix-plan-empty"]'),
      ).toBeVisible({ timeout: 5_000 });

      // ── Step 7: Switch make-day to tomorrow ──────────────────────────────────
      const makeDayPicker = page.locator('[data-testid="mix-make-day"]');
      await makeDayPicker.fill(tomorrowStr);
      // Tab away to trigger onChange (the date input fires on blur/change).
      await makeDayPicker.press("Tab");
      await page.waitForTimeout(800);

      // ── Step 8: Verify the group card for tomorrow is present ────────────────
      const tomorrowCard = page.locator(`[data-testid="mix-plan-${tomorrowStr}"]`);
      await tomorrowCard.waitFor({ state: "visible", timeout: 8_000 });

      // "Ingredient Prep" section heading confirms buildMixPlan found a prep match.
      await expect(
        tomorrowCard.getByText("Ingredient Prep", { exact: false }),
      ).toBeVisible({ timeout: 5_000 });

      // The mix name must appear inside the group card.
      await expect(
        tomorrowCard.getByText(mixName, { exact: false }),
      ).toBeVisible({ timeout: 5_000 });

      // "Pull For Prep" section heading confirms the pull-lbs breakdown is rendered.
      await expect(
        tomorrowCard.getByText("Pull For Prep", { exact: false }),
      ).toBeVisible({ timeout: 5_000 });

      // The ingredient name must appear in the pull-for-prep section.
      await expect(
        tomorrowCard.getByText(ingredient, { exact: false }),
      ).toBeVisible({ timeout: 5_000 });

      // ── Step 9: Verify the pull lbs use profile oz, not the mix-card fallback ─
      const ingredientRow = tomorrowCard
        .locator("div", { has: page.getByText(ingredient, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();

      // Profile-derived lbs = (RUN_OZ / 16) × 800 = 100.00.
      expect(rowText).toContain(expectedPullLbs.toFixed(2));
      // If the code ignores ingredientOzPerPizza and falls back to MIX_CARD_OZ
      // the result would be 25.00 — asserting it is absent proves the profile path.
      expect(rowText).not.toContain(wrongFallbackLbs.toFixed(2));

      // ── Step 10: Switch back to today → empty-state is restored ─────────────
      await makeDayPicker.fill(todayStr());
      await makeDayPicker.press("Tab");
      await page.waitForTimeout(800);

      await expect(
        page.locator('[data-testid="mix-plan-empty"]'),
      ).toBeVisible({ timeout: 5_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      // Restore or remove the daily_sync row losslessly: if one existed before
      // the test, upsert it back; otherwise delete only the test-inserted row.
      if (preExistingRow !== null) {
        await db
          .query(
            `INSERT INTO daily_sync (date, scope, data, updated_at)
             VALUES ($1, 'live', $2::jsonb, $3)
             ON CONFLICT (date, scope) DO UPDATE
               SET data = EXCLUDED.data, updated_at = EXCLUDED.updated_at`,
            [tomorrowStr, JSON.stringify(preExistingRow.data), preExistingRow.updated_at],
          )
          .catch((err: unknown) => {
            console.error("WARN: failed to restore daily_sync row:", err);
          });
      } else {
        await db
          .query(
            "DELETE FROM daily_sync WHERE date = $1 AND scope = 'live'",
            [tomorrowStr],
          )
          .catch(() => {});
      }
      await db
        .query("DELETE FROM users WHERE username = $1", [username])
        .catch(() => {});
    }
  });

  /**
   * Test (daysEarly=0 boundary): A prep mix with daysEarly=0 is ABSENT when
   * make-day is today (du=1 for a tomorrow run) and IS present when make-day
   * is tomorrow (du=0 — the run day itself).
   *
   * The filter in lib/mixes/src/index.ts is `if (du > mix.daysEarly) continue`.
   * With daysEarly=0:
   *   • du=1 (today → tomorrow run) → 1 > 0 is true  → skip → ABSENT ✓
   *   • du=0 (tomorrow → tomorrow run) → 0 > 0 is false → include → PRESENT ✓
   *
   * An off-by-one (`du >= mix.daysEarly`) would include the card one day early,
   * confusing floor staff who haven't prepped that ingredient yet.
   */
  test("prep mix with daysEarly=0 is absent the day before the run and present on the run day", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `days-early-zero-${suffix}`;
    const mixName = `ZeroEarlyPrepMix ${suffix}`;
    const ingredient = `ZeroEarlyHerb_${suffix}`;
    const brand = `ZeroEarlyBrand_${suffix}`;
    const flavor = "";

    const MIX_CARD_OZ = 0.5;
    const RUN_OZ = 2.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 800
    const expectedPullLbs = (RUN_OZ / 16) * totalPizzas; // 100.00

    const tomorrowLocal = new Date();
    tomorrowLocal.setDate(tomorrowLocal.getDate() + 1);
    const tomorrowStr = localDateStr(tomorrowLocal);

    const scheduledRunId = `sched-ze-run-${suffix}`;
    let preExistingRow: { data: unknown; updated_at: Date } | null = null;

    try {
      // ── Step 1: Insert the prep mix with daysEarly=0 ─────────────────────────
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: MIX_CARD_OZ,
        daysEarly: 0,
      });

      // ── Step 2: Snapshot + upsert a scheduled run for tomorrow in daily_sync ──
      const existingResult = await db.query<{ data: unknown; updated_at: Date }>(
        `SELECT data, updated_at FROM daily_sync WHERE date = $1 AND scope = 'live'`,
        [tomorrowStr],
      );
      preExistingRow = existingResult.rows.length > 0 ? existingResult.rows[0] : null;

      const scheduledData = {
        dayState: {
          runs: [{ id: scheduledRunId, brand, flavor }],
        },
        runValues: {
          [scheduledRunId]: { casesNeeded: CASES_NEEDED },
        },
      };
      await db.query(
        `INSERT INTO daily_sync (date, scope, data, updated_at)
         VALUES ($1, 'live', $2::jsonb, NOW())
         ON CONFLICT (date, scope) DO UPDATE
           SET data = $2::jsonb, updated_at = NOW()`,
        [tomorrowStr, JSON.stringify(scheduledData)],
      );

      // ── Step 3: Sign up and dismiss onboarding ───────────────────────────────
      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await page.waitForTimeout(1_000);

      // ── Step 4: Inject the profile into localStorage ─────────────────────────
      // valsToMixRun maps pep1Type → ingredientOzPerPizza so buildMixPlan uses
      // profile-derived oz instead of the mix-card fallback.
      await page.evaluate(
        ({ brand, flavor, ingredient, runOz, pizzasPerCase }) => {
          const profileKey = `run-calc-profile-${brand.toLowerCase().trim()}__${flavor.toLowerCase().trim()}`;
          const existing = (() => {
            try {
              return JSON.parse(localStorage.getItem(profileKey) ?? "{}");
            } catch {
              return {};
            }
          })();
          localStorage.setItem(
            profileKey,
            JSON.stringify({
              ...existing,
              pep1Type: ingredient,
              pep1OzPerPizza: runOz,
              pizzasPerCase,
            }),
          );
        },
        { brand, flavor, ingredient, runOz: RUN_OZ, pizzasPerCase: PIZZAS_PER_CASE },
      );
      await dbSeedProfile(db, {
        brand,
        flavor,
        ingredient,
        runOz: RUN_OZ,
        pizzasPerCase: PIZZAS_PER_CASE,
      });
      await page.reload({ waitUntil: "domcontentloaded" });

      // ── Step 5: Navigate to the Mixes tab ────────────────────────────────────
      await goToMixes(page);
      await page.waitForTimeout(500);

      // ── Step 6: Today (default make-day, du=1) → card is ABSENT ─────────────
      // daysEarly=0 means same-day-only; du=1 > 0 → the filter skips this mix.
      // The seeded placeholder run has no brand/ingredient, so buildMixPlan
      // returns [] → empty-state.
      await expect(
        page.locator('[data-testid="mix-plan-empty"]'),
      ).toBeVisible({ timeout: 5_000 });
      // Confirm the mix name really isn't anywhere on the page.
      await expect(page.getByText(mixName, { exact: false })).toHaveCount(0, { timeout: 3_000 });

      // ── Step 7: Switch make-day to tomorrow (du=0) ───────────────────────────
      const makeDayPicker = page.locator('[data-testid="mix-make-day"]');
      await makeDayPicker.fill(tomorrowStr);
      await makeDayPicker.press("Tab");
      await page.waitForTimeout(800);

      // ── Step 8: Verify the group card for tomorrow IS present ────────────────
      // du=0 for the tomorrow run when make-day=tomorrow; 0 > 0 is false → included.
      const tomorrowCard = page.locator(`[data-testid="mix-plan-${tomorrowStr}"]`);
      await tomorrowCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(
        tomorrowCard.getByText("Ingredient Prep", { exact: false }),
      ).toBeVisible({ timeout: 5_000 });
      await expect(
        tomorrowCard.getByText(mixName, { exact: false }),
      ).toBeVisible({ timeout: 5_000 });
      await expect(
        tomorrowCard.getByText("Pull For Prep", { exact: false }),
      ).toBeVisible({ timeout: 5_000 });
      await expect(
        tomorrowCard.getByText(ingredient, { exact: false }),
      ).toBeVisible({ timeout: 5_000 });

      // Pull lbs must use profile oz (100.00), not mix-card fallback (25.00).
      const ingredientRow = tomorrowCard
        .locator("div", { has: page.getByText(ingredient, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();
      expect(rowText).toContain(expectedPullLbs.toFixed(2)); // "100.00"
      expect(rowText).not.toContain(((MIX_CARD_OZ / 16) * totalPizzas).toFixed(2)); // not "25.00"

      // ── Step 9: Switch back to today → absent again ───────────────────────────
      await makeDayPicker.fill(todayStr());
      await makeDayPicker.press("Tab");
      await page.waitForTimeout(800);

      await expect(
        page.locator('[data-testid="mix-plan-empty"]'),
      ).toBeVisible({ timeout: 5_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      if (preExistingRow !== null) {
        await db
          .query(
            `INSERT INTO daily_sync (date, scope, data, updated_at)
             VALUES ($1, 'live', $2::jsonb, $3)
             ON CONFLICT (date, scope) DO UPDATE
               SET data = EXCLUDED.data, updated_at = EXCLUDED.updated_at`,
            [tomorrowStr, JSON.stringify(preExistingRow.data), preExistingRow.updated_at],
          )
          .catch((err: unknown) => {
            console.error("WARN: failed to restore daily_sync row:", err);
          });
      } else {
        await db
          .query(
            "DELETE FROM daily_sync WHERE date = $1 AND scope = 'live'",
            [tomorrowStr],
          )
          .catch(() => {});
      }
      await db
        .query("DELETE FROM users WHERE username = $1", [username])
        .catch(() => {});
    }
  });

  /**
   * Test (g2): Prep mix card appears when a run profile uses a QUALIFIED
   * ingredient name (e.g. "Herb - Dried") whose base name matches the mix
   * component "Herb".
   *
   * ingredientMatches() treats two names as equivalent when the shorter is a
   * word-boundary prefix of the longer.
   */
  test("prep mix card appears when run uses a qualified ingredient name matching the mix component base name", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-prefix-${suffix}`;
    const mixName = `PrefixPrepMix ${suffix}`;

    const componentBase = `Herb_${suffix}`;
    const qualifiedIngredient = `${componentBase} - Dried`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 3.0;
    const CASES_NEEDED = 80;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 640
    const expectedPullLbs = (RUN_OZ / 16) * totalPizzas; // 120.00

    const MIX_CARD_OZ = 0.1;
    const wrongFallbackLbs = (MIX_CARD_OZ / 16) * totalPizzas; // 4.00

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: componentBase,
        perPizza: MIX_CARD_OZ,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, qualifiedIngredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: qualifiedIngredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, qualifiedIngredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(componentBase, { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(componentBase, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();

      const expectedStr = expectedPullLbs.toFixed(2);       // "120.00"
      const wrongFallbackStr = wrongFallbackLbs.toFixed(2); //   "4.00"

      expect(rowText).toContain(expectedStr);
      expect(rowText).not.toContain(wrongFallbackStr);
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (h2): Pull For Prep updates live when the already-made field is edited.
   *
   * Step A: amountAlreadyMade=0 → pull = full componentLbs (100.00)
   * Step B: type 50 → pull ≈ 62.96
   * Step C: type 200 (>= totalLbs 135) → pull = 0.00
   */
  test("Pull For Prep updates live when the already-made field is edited in the UI", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-live-edit-${suffix}`;
    const mixName = `LiveEditPrepMix ${suffix}`;
    const ingredient = `LiveEditHerb_${suffix}`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 2.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 800
    const MIX_WASTE_FACTOR = 0.15;
    const STARTUP_LBS = 20;
    const componentLbs = (RUN_OZ / 16) * totalPizzas;                         // 100.00
    const totalLbs = componentLbs * (1 + MIX_WASTE_FACTOR) + STARTUP_LBS;     // 135.00

    const fullPullStr = componentLbs.toFixed(2); // "100.00"

    const PARTIAL_ALREADY_MADE = 50;
    const remainingAfterPartial = totalLbs - PARTIAL_ALREADY_MADE;             //  85.00
    const partialPullLbs = componentLbs * remainingAfterPartial / totalLbs;    // ≈62.96
    const partialPullStr = partialPullLbs.toFixed(2);                          // "62.96"

    const FULL_COVERAGE = 200;

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: RUN_OZ,
        amountAlreadyMade: 0,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, ingredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: ingredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, ingredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(ingredient, { exact: true }) })
        .last();
      expect(await ingredientRow.innerText()).toContain(fullPullStr);

      const alreadyMadeInput = todayCard.locator('input[type="number"]').first();
      await alreadyMadeInput.waitFor({ state: "visible", timeout: 5_000 });
      await alreadyMadeInput.fill(String(PARTIAL_ALREADY_MADE));
      await alreadyMadeInput.blur();
      await page.waitForTimeout(2_500);

      const partialText = await ingredientRow.innerText();
      expect(partialText).toContain(partialPullStr);
      expect(partialText).not.toContain(fullPullStr);

      await alreadyMadeInput.fill(String(FULL_COVERAGE));
      await alreadyMadeInput.blur();
      await page.waitForTimeout(2_500);

      expect(await ingredientRow.innerText()).toContain("0.00");
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (i2): "need X lbs" badge on a regular (non-prep) mix card reflects
   * the correct remaining amount when amountAlreadyMade < totalLbs.
   */
  test("need X lbs badge on regular mix card shows correct remaining amount", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `reg-need-${suffix}`;
    const mixName = `RegNeedMix ${suffix}`;
    const component = `RegComp_${suffix}`;
    const brand = `RegBrand_${suffix}`;
    const today = todayStr();

    const PER_PIZZA_OZ = 2.0;
    const BATCH_SIZE = 10;
    const AMOUNT_ALREADY_MADE = 20;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;

    const pizzas = CASES_NEEDED * PIZZAS_PER_CASE;            // 800
    const componentLbs = (PER_PIZZA_OZ * pizzas) / 16;        // 100.00
    const MIX_WASTE_FACTOR = 0.15;
    const STARTUP_LBS = 20;
    const totalLbs = componentLbs * (1 + MIX_WASTE_FACTOR) + STARTUP_LBS; // 135.00
    const remainingLbs = totalLbs - AMOUNT_ALREADY_MADE;       // 115.00
    const pullLbs = componentLbs * remainingLbs / totalLbs;    // ≈85.19

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        brand,
        isPrep: false,
        component,
        perPizza: PER_PIZZA_OZ,
        batchSize: BATCH_SIZE,
        amountAlreadyMade: AMOUNT_ALREADY_MADE,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({ ...existing, casesNeeded, pizzasPerCase, casesPerLayer: 0 }));
        },
        { brand, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });

      const needStr = remainingLbs.toFixed(2); // "115.00"
      await expect(todayCard.getByText(`need ${needStr} lbs`, { exact: false })).toBeVisible({ timeout: 5_000 });

      await expect(todayCard.getByText("Pull For Mix", { exact: false })).toBeVisible({ timeout: 5_000 });

      const pullStr = pullLbs.toFixed(2); // "85.19"
      const componentRow = todayCard.locator("div", { has: page.getByText(component, { exact: true }) }).last();
      const componentRowText = await componentRow.innerText();
      expect(componentRowText).toContain(pullStr);
      expect(componentRowText).not.toContain(componentLbs.toFixed(2));
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (j2): "need 0.00 lbs" badge on a regular mix card when
   * amountAlreadyMade >= totalLbs (fully covered).
   */
  test("need 0.00 lbs badge appears on regular mix card when amountAlreadyMade >= totalLbs", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `reg-full-${suffix}`;
    const mixName = `RegFullMix ${suffix}`;
    const component = `RegFullComp_${suffix}`;
    const brand = `RegFullBrand_${suffix}`;
    const today = todayStr();

    const PER_PIZZA_OZ = 2.0;
    const BATCH_SIZE = 10;
    const AMOUNT_ALREADY_MADE = 200;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        brand,
        isPrep: false,
        component,
        perPizza: PER_PIZZA_OZ,
        batchSize: BATCH_SIZE,
        amountAlreadyMade: AMOUNT_ALREADY_MADE,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({ ...existing, casesNeeded, pizzasPerCase, casesPerLayer: 0 }));
        },
        { brand, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("need 0.00 lbs", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Mix", { exact: false })).toBeVisible({ timeout: 5_000 });

      const componentRow = todayCard.locator("div", { has: page.getByText(component, { exact: true }) }).last();
      expect(await componentRow.innerText()).toContain("0.00");
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (h3): Pull For Prep updates live when "already made" is edited and TWO
   * runs share the prep ingredient.
   *
   * This is the multi-run live-reactivity counterpart to test (h2).
   * After editing amountAlreadyMade the ingredient-row pull quantity must
   * recalculate immediately without a page reload, using the same proportional
   * formula as the static multi-run case (test h):
   *
   *   contrib1Lbs = (2.0/16) × 800  = 100.00
   *   contrib2Lbs = (1.5/16) × 400  =  37.50
   *   componentLbs                   = 137.50
   *   totalLbs    = 137.50×1.15 + 20 = 178.125
   *
   *   amountAlreadyMade = 0   → pull = componentLbs         = 137.50
   *   amountAlreadyMade = 50  → pull = 137.50×128.125/178.125 ≈  98.90
   *   amountAlreadyMade = 300 → pull = max(0,…)              =   0.00
   */
  test("Pull For Prep updates live when already-made is edited and two runs share the prep ingredient", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-live-multi-${suffix}`;
    const mixName = `LiveMultiPrepMix ${suffix}`;
    const ingredient = `LiveMultiHerb_${suffix}`;
    const today = todayStr();

    const brand1 = `AlphaLive_${suffix}`;
    const OZ1 = 2.0;
    const CASES1 = 100;
    const PPC = 8;

    const brand2 = `BetaLive_${suffix}`;
    const OZ2 = 1.5;
    const CASES2 = 50;

    const pizzas1 = CASES1 * PPC;  // 800
    const pizzas2 = CASES2 * PPC;  // 400

    const contrib1Lbs = (OZ1 / 16) * pizzas1;  // 100.00
    const contrib2Lbs = (OZ2 / 16) * pizzas2;  //  37.50
    const componentLbs = contrib1Lbs + contrib2Lbs; // 137.50

    const MIX_WASTE_FACTOR = 0.15;
    const STARTUP_LBS = 20;
    const totalLbs = componentLbs * (1 + MIX_WASTE_FACTOR) + STARTUP_LBS; // 178.125

    const fullPullStr = componentLbs.toFixed(2); // "137.50"

    const PARTIAL_ALREADY_MADE = 50;
    const remainingAfterPartial = totalLbs - PARTIAL_ALREADY_MADE;         // 128.125
    const partialPullLbs = componentLbs * remainingAfterPartial / totalLbs; // ≈98.90
    const partialPullStr = partialPullLbs.toFixed(2);                       // "98.90"

    const FULL_COVERAGE = 300;

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: OZ1,
        amountAlreadyMade: 0,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await makeTestUserManager(username);

      // Inject two runs sharing the same ingredient via localStorage
      await page.evaluate(
        ({ brand1, brand2, ingredient, oz1, oz2, cases1, cases2, ppc }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;

          day.runs[0].brand = brand1;
          const runId1 = day.runs[0].id;
          const existing1 = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId1)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId1), JSON.stringify({
            ...existing1, pep1Type: ingredient, pep1OzPerPizza: oz1,
            casesNeeded: cases1, pizzasPerCase: ppc, casesPerLayer: 0,
          }));

          const runId2 = `e2e-livemulti-run2-${Math.random().toString(36).slice(2, 9)}`;
          day.runs.push({ id: runId2, brand: brand2 });
          localStorage.setItem(RUN_KEY(runId2), JSON.stringify({
            pep1Type: ingredient, pep1OzPerPizza: oz2,
            casesNeeded: cases2, pizzasPerCase: ppc, casesPerLayer: 0,
          }));
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
        },
        { brand1, brand2, ingredient, oz1: OZ1, oz2: OZ2, cases1: CASES1, cases2: CASES2, ppc: PPC },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(ingredient, { exact: true }) })
        .last();

      // Step A: amountAlreadyMade = 0 → pull = componentLbs (137.50)
      expect(await ingredientRow.innerText()).toContain(fullPullStr);

      // Step B: edit to 50 → pull ≈ 98.90
      const alreadyMadeInput = todayCard.locator('input[type="number"]').first();
      await alreadyMadeInput.waitFor({ state: "visible", timeout: 5_000 });
      await alreadyMadeInput.fill(String(PARTIAL_ALREADY_MADE));
      await alreadyMadeInput.blur();
      await page.waitForTimeout(2_500);

      const partialText = await ingredientRow.innerText();
      expect(partialText).toContain(partialPullStr);
      expect(partialText).not.toContain(fullPullStr);

      // Step C: edit to 300 (>= totalLbs 178.125) → pull = 0.00
      await alreadyMadeInput.fill(String(FULL_COVERAGE));
      await alreadyMadeInput.blur();
      await page.waitForTimeout(2_500);

      expect(await ingredientRow.innerText()).toContain("0.00");
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (k): 'need X lbs' badge on a regular (non-prep, brand-scoped) mix card
   * updates immediately when the manager edits the "already made" field.
   *
   * Mechanism: onBlur → saveMixes → onSaved → cycleCountQc.setQueryData(["mixes"], saved)
   * → useMixes returns the updated list → buildMixPlan re-runs with the new
   * amountAlreadyMade → m.remainingLbs changes → badge re-renders without a reload.
   *
   * The badge (home.tsx ~14556) is:
   *   {m.remainingLbs < m.totalLbs && <span>need {fmtNum(m.remainingLbs, 2)} lbs</span>}
   *
   * So:
   *   amountAlreadyMade = 0          → remainingLbs = totalLbs → badge absent
   *   amountAlreadyMade = 50         → remainingLbs = 85.00   → badge "need 85.00 lbs"
   *   amountAlreadyMade >= totalLbs  → remainingLbs = 0       → badge "need 0.00 lbs"
   *
   * Math (same as test (i2)):
   *   componentLbs = (2.0/16) × 800        = 100.00
   *   totalLbs     = 100 × 1.15 + 20       = 135.00
   *   remainingLbs (partial) = 135 − 50    =  85.00
   */
  test("'need X lbs' badge on a regular mix card updates live when 'already made' is edited", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `reg-live-edit-${suffix}`;
    const mixName = `RegLiveEditMix ${suffix}`;
    const component = `RegLiveComp_${suffix}`;
    const brand = `RegLiveBrand_${suffix}`;
    const today = todayStr();

    const PER_PIZZA_OZ = 2.0;
    const BATCH_SIZE = 10;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 800

    const MIX_WASTE_FACTOR = 0.15;
    const STARTUP_LBS = 20;
    const componentLbs = (PER_PIZZA_OZ * totalPizzas) / 16;                    // 100.00
    const totalLbs = componentLbs * (1 + MIX_WASTE_FACTOR) + STARTUP_LBS;     // 135.00

    const PARTIAL_AMOUNT = 50;
    const remainingAfterPartial = totalLbs - PARTIAL_AMOUNT;                   //  85.00
    const partialBadgeStr = remainingAfterPartial.toFixed(2);                  // "85.00"

    const FULL_COVERAGE = 200; // > totalLbs → remainingLbs = 0

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        brand,
        isPrep: false,
        component,
        perPizza: PER_PIZZA_OZ,
        batchSize: BATCH_SIZE,
        amountAlreadyMade: 0,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      // Inject brand + case count directly into localStorage so the mix plan
      // has a live run it can match on (same pattern used throughout this suite).
      await page.evaluate(
        ({ brand, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Mix", { exact: false })).toBeVisible({ timeout: 5_000 });

      // ── Step 1: badge is ABSENT initially (amountAlreadyMade = 0, remainingLbs = totalLbs) ──
      await expect(todayCard.getByText(/need .+ lbs/, { exact: false })).toHaveCount(0, { timeout: 3_000 });

      // ── Step 2: type partial amount (50) and blur → badge appears with remainingLbs ──
      const alreadyMadeInput = todayCard.locator('input[type="number"]').first();
      await alreadyMadeInput.waitFor({ state: "visible", timeout: 5_000 });
      await alreadyMadeInput.click();
      await alreadyMadeInput.fill(String(PARTIAL_AMOUNT));
      await alreadyMadeInput.blur();
      await page.waitForTimeout(2_500);

      await expect(
        todayCard.getByText(`need ${partialBadgeStr} lbs`, { exact: false }),
      ).toBeVisible({ timeout: 5_000 });

      // ── Step 3: type a value >= totalLbs (200) → badge shows "need 0.00 lbs" ──
      await alreadyMadeInput.click();
      await alreadyMadeInput.fill(String(FULL_COVERAGE));
      await alreadyMadeInput.blur();
      await page.waitForTimeout(2_500);

      await expect(
        todayCard.getByText("need 0.00 lbs", { exact: false }),
      ).toBeVisible({ timeout: 5_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (k2): A failed already-made save keeps the manager's typed amount so
   * the same input can be retried without re-entering it.
   */
  test("manager can retry an already-made amount after the first save fails", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `reg-retry-save-${suffix}`;
    const mixName = `RegRetrySaveMix ${suffix}`;
    const component = `RegRetryComp_${suffix}`;
    const brand = `RegRetryBrand_${suffix}`;
    const today = todayStr();
    const alreadyMade = 50;
    const totalLbs = (2 * 100 * 8 / 16) * 1.15 + 20;
    const remainingLbs = totalLbs - alreadyMade;
    let postAttempts = 0;

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        brand,
        isPrep: false,
        component,
        perPizza: 2,
        batchSize: 10,
        amountAlreadyMade: 0,
      });

      await seedLiveRunBeforeAppLoad(page, {
        runId: `reg-retry-save-run-${suffix}`,
        brand,
        ingredient: component,
        runOz: 2,
        casesNeeded: 100,
        pizzasPerCase: 8,
        casesPerLayer: 0,
      });
      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await makeTestUserManager(username);
      await page.goto("/", { waitUntil: "domcontentloaded" });
      await page.waitForTimeout(1_000);

      await page.route("**/api/mixes", async (route) => {
        if (route.request().method() !== "POST") {
          await route.continue();
          return;
        }
        postAttempts += 1;
        if (postAttempts === 1) {
          await route.fulfill({
            status: 503,
            contentType: "application/json",
            body: JSON.stringify({ error: "forced e2e failure" }),
          });
          return;
        }
        await route.continue();
      });

      await goToMixes(page);
      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });

      const input = todayCard.locator('input[type="number"]').first();
      await input.fill(String(alreadyMade));
      await input.blur();

      await expect(page.getByText("Couldn't save already made amount", { exact: true }))
        .toBeVisible({ timeout: 5_000 });
      await expect(input).toHaveValue(String(alreadyMade));
      expect(postAttempts).toBe(1);

      await input.focus();
      await input.blur();

      // The controlled field is the live Mix Plan's visible representation of
      // the saved amount; it must still show the same value after the retry.
      await expect(input).toHaveValue(String(alreadyMade));
      expect(postAttempts).toBe(2);
    } finally {
      await page.unroute("**/api/mixes").catch(() => {});
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (k3): A failed first save can be retried successfully, and the
   * retried value remains visible after Mix Plan hydrates again from the
   * server.
   */
  test("retried already-made amount survives a later Mix Plan reload", async ({
    page,
  }) => {
    test.setTimeout(90_000);
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `reg-retry-reload-${suffix}`;
    const mixName = `RegRetryReloadMix ${suffix}`;
    const component = `RegRetryReloadComp_${suffix}`;
    const brand = `RegRetryReloadBrand_${suffix}`;
    const runId = `reg-retry-reload-run-${suffix}`;
    const today = todayStr();
    const alreadyMade = 50;
    const totalLbs = (2 * 100 * 8 / 16) * 1.15 + 20;
    const remainingLbs = totalLbs - alreadyMade;
    let postAttempts = 0;

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        brand,
        isPrep: false,
        component,
        perPizza: 2,
        batchSize: 10,
        amountAlreadyMade: 0,
      });

      await seedLiveRunBeforeAppLoad(page, {
        runId,
        brand,
        ingredient: component,
        runOz: 2,
        casesNeeded: 100,
        pizzasPerCase: 8,
        casesPerLayer: 0,
      });
      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await makeTestUserManager(username);
      const seedStamp = Date.now();
      await db.query(
        `INSERT INTO daily_sync (date, scope, data, updated_at)
         VALUES ($1, 'live', $2::jsonb, NOW())
         ON CONFLICT (date, scope) DO UPDATE
           SET data = $2::jsonb, updated_at = NOW()`,
        [today, JSON.stringify({
          dayState: {
            runs: [{ id: runId, brand, flavor: "", seeded: false, metaUpdatedAt: seedStamp }],
            currentIndex: 0,
            currentRunId: runId,
            date: today,
            resetAt: 0,
          },
          runValues: {
            [runId]: {
              pep1Type: component,
              pep1OzPerPizza: 2,
              casesNeeded: 100,
              pizzasPerCase: 8,
              casesPerLayer: 0,
            },
          },
          runValuesUpdatedAt: { [runId]: seedStamp },
        })],
      );
      await page.goto("/", { waitUntil: "domcontentloaded" });
      await page.waitForTimeout(1_000);

      await page.route("**/api/mixes", async (route) => {
        if (route.request().method() !== "POST") {
          await route.continue();
          return;
        }
        postAttempts += 1;
        if (postAttempts === 1) {
          await route.fulfill({
            status: 503,
            contentType: "application/json",
            body: JSON.stringify({ error: "forced e2e failure" }),
          });
          return;
        }
        await route.continue();
      });

      await goToMixes(page);
      const todayCard = await waitForTodayMixPlanCard(page, today);
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });

      const input = todayCard.locator('input[type="number"]').first();
      await input.fill(String(alreadyMade));
      await input.blur();

      await expect(page.getByText("Couldn't save already made amount", { exact: true }))
        .toBeVisible({ timeout: 5_000 });
      await expect(input).toHaveValue(String(alreadyMade));
      expect(postAttempts).toBe(1);

      await input.focus();
      await input.blur();
      await expect(input).toHaveValue(String(alreadyMade));
      expect(postAttempts).toBe(2);

      await expect.poll(
        async () => Number((await db.query(
          "SELECT amount_already_made FROM mixes WHERE id = $1",
          [mixId],
        )).rows[0]?.amount_already_made ?? 0),
        { timeout: 5_000 },
      ).toBe(alreadyMade);
      await expect.poll(async () => {
        const response = await page.request.get(`/api/sync/today?today=${today}`);
        if (!response.ok()) return false;
        const payload = await response.json() as {
          dayState?: { runs?: Array<{ id?: string }> };
        };
        return payload.dayState?.runs?.some((run) => run.id === runId) ?? false;
      }, { timeout: 15_000 }).toBe(true);

      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      const reloadedCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await reloadedCard.waitFor({ state: "visible", timeout: 20_000 }).catch(async () => {
        await page.reload({ waitUntil: "domcontentloaded" });
        await page.locator('[data-testid="tab-run"]')
          .waitFor({ state: "attached", timeout: 25_000 });
        await goToMixes(page);
        await reloadedCard.waitFor({ state: "visible", timeout: 20_000 });
      });
      await expect(reloadedCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });

      const savedInput = reloadedCard.locator('input[type="number"]').first();
      await savedInput.waitFor({ state: "visible", timeout: 5_000 });
      await expect(savedInput).toHaveValue(String(alreadyMade), { timeout: 5_000 });
      await expect(
        reloadedCard.getByText(`need ${remainingLbs.toFixed(2)} lbs`, { exact: false }),
      ).toBeVisible({ timeout: 5_000 });
    } finally {
      await page.unroute("**/api/mixes").catch(() => {});
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (l): Prep mix with daysEarly=1 appears on the run day AND one day
   * early, but is absent two days before (outside the window).
   *
   * Mechanism: buildMixPlan (~line 1033 in lib/mixes/src/index.ts) filters
   * prep mixes with `if (du > mix.daysEarly) continue`, where du = daysUntil(
   * runDate, makeDay). For a prep mix with daysEarly=1 and a run on day+2:
   *
   *   make-day = day+2 (run day)   → du = 0  ≤ 1  → card SHOWN
   *   make-day = day+1 (one early) → du = 1  ≤ 1  → card SHOWN
   *   make-day = today  (day+0)    → du = 2  > 1  → card ABSENT
   *
   * Setup mirrors the "scheduled future-day run" test: the run is inserted
   * directly into daily_sync so the startup fetch sees it, and a profile is
   * injected into localStorage so valsToMixRun() builds the ingredient list.
   */
  test("prep mix with daysEarly=1 appears on the run day and one day early but not two days before", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `days-early-prep-${suffix}`;
    const mixName = `DaysEarlyPrepMix ${suffix}`;
    const ingredient = `DaysEarlyHerb_${suffix}`;
    const brand = `DaysEarlyBrand_${suffix}`;
    const flavor = "";

    const DAYS_EARLY = 1;
    const RUN_OZ = 2.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;

    // The scheduled run is two days from today.
    const runDateLocal = new Date();
    runDateLocal.setDate(runDateLocal.getDate() + 2);
    const runDateStr = localDateStr(runDateLocal);

    // The "one day early" make-day is tomorrow.
    const oneDayEarlyLocal = new Date();
    oneDayEarlyLocal.setDate(oneDayEarlyLocal.getDate() + 1);
    const oneDayEarlyStr = localDateStr(oneDayEarlyLocal);

    const scheduledRunId = `sched-de-run-${suffix}`;

    // Snapshot existing daily_sync row for the run date so teardown can restore it.
    let preExistingRow: { data: unknown; updated_at: Date } | null = null;

    try {
      // ── Step 1: Insert the prep mix with daysEarly = 1 ──────────────────────
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: 0.5,
        daysEarly: DAYS_EARLY,
      });

      // ── Step 2: Snapshot + upsert scheduled run for day+2 ───────────────────
      const existingResult = await db.query<{ data: unknown; updated_at: Date }>(
        `SELECT data, updated_at FROM daily_sync WHERE date = $1 AND scope = 'live'`,
        [runDateStr],
      );
      preExistingRow = existingResult.rows.length > 0 ? existingResult.rows[0] : null;

      const scheduledData = {
        dayState: {
          runs: [{ id: scheduledRunId, brand, flavor }],
        },
        runValues: {
          [scheduledRunId]: { casesNeeded: CASES_NEEDED },
        },
      };
      await db.query(
        `INSERT INTO daily_sync (date, scope, data, updated_at)
         VALUES ($1, 'live', $2::jsonb, NOW())
         ON CONFLICT (date, scope) DO UPDATE
           SET data = $2::jsonb, updated_at = NOW()`,
        [runDateStr, JSON.stringify(scheduledData)],
      );

      // ── Step 3: Sign up and dismiss onboarding ───────────────────────────────
      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await page.waitForTimeout(1_000);

      // ── Step 4: Inject profile into localStorage ─────────────────────────────
      // loadProfile(brand, flavor) → valsToMixRun maps pep1Type → ingredient list.
      await page.evaluate(
        ({ brand, flavor, ingredient, runOz, pizzasPerCase }) => {
          const profileKey = `run-calc-profile-${brand.toLowerCase().trim()}__${flavor.toLowerCase().trim()}`;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(profileKey) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(profileKey, JSON.stringify({
            ...existing,
            pep1Type: ingredient,
            pep1OzPerPizza: runOz,
            pizzasPerCase,
          }));
        },
        { brand, flavor, ingredient, runOz: RUN_OZ, pizzasPerCase: PIZZAS_PER_CASE },
      );
      await dbSeedProfile(db, {
        brand,
        flavor,
        ingredient,
        runOz: RUN_OZ,
        pizzasPerCase: PIZZAS_PER_CASE,
      });
      await page.reload({ waitUntil: "domcontentloaded" });

      // ── Step 5: Navigate to Mixes tab ────────────────────────────────────────
      await goToMixes(page);
      await page.waitForTimeout(500);

      // ── Scenario A: make-day = today (day+0) → du=2 > daysEarly=1 → absent ──
      // Default make-day is today; no live run uses the ingredient → empty state.
      await expect(
        page.locator('[data-testid="mix-plan-empty"]'),
      ).toBeVisible({ timeout: 5_000 });
      await expect(page.getByText(mixName, { exact: false })).toHaveCount(0, { timeout: 3_000 });

      // ── Scenario B: make-day = day+1 (one day early) → du=1 ≤ 1 → shown ─────
      const makeDayPicker = page.locator('[data-testid="mix-make-day"]');
      await makeDayPicker.fill(oneDayEarlyStr);
      await makeDayPicker.press("Tab");
      await page.waitForTimeout(800);

      const oneDayEarlyCard = page.locator(`[data-testid="mix-plan-${runDateStr}"]`);
      await oneDayEarlyCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(
        oneDayEarlyCard.getByText("Ingredient Prep", { exact: false }),
      ).toBeVisible({ timeout: 5_000 });
      await expect(
        oneDayEarlyCard.getByText(mixName, { exact: false }),
      ).toBeVisible({ timeout: 5_000 });
      await expect(
        oneDayEarlyCard.getByText("Pull For Prep", { exact: false }),
      ).toBeVisible({ timeout: 5_000 });
      await expect(
        oneDayEarlyCard.getByText(ingredient, { exact: false }),
      ).toBeVisible({ timeout: 5_000 });

      // ── Scenario C: make-day = day+2 (run day) → du=0 ≤ 1 → shown ───────────
      await makeDayPicker.fill(runDateStr);
      await makeDayPicker.press("Tab");
      await page.waitForTimeout(800);

      const runDayCard = page.locator(`[data-testid="mix-plan-${runDateStr}"]`);
      await runDayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(
        runDayCard.getByText("Ingredient Prep", { exact: false }),
      ).toBeVisible({ timeout: 5_000 });
      await expect(
        runDayCard.getByText(mixName, { exact: false }),
      ).toBeVisible({ timeout: 5_000 });

      // ── Scenario D: switch back to today → absent again ───────────────────────
      await makeDayPicker.fill(todayStr());
      await makeDayPicker.press("Tab");
      await page.waitForTimeout(800);

      await expect(
        page.locator('[data-testid="mix-plan-empty"]'),
      ).toBeVisible({ timeout: 5_000 });
      await expect(page.getByText(mixName, { exact: false })).toHaveCount(0, { timeout: 3_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      if (preExistingRow !== null) {
        await db
          .query(
            `INSERT INTO daily_sync (date, scope, data, updated_at)
             VALUES ($1, 'live', $2::jsonb, $3)
             ON CONFLICT (date, scope) DO UPDATE
               SET data = EXCLUDED.data, updated_at = EXCLUDED.updated_at`,
            [runDateStr, JSON.stringify(preExistingRow.data), preExistingRow.updated_at],
          )
          .catch((err: unknown) => {
            console.error("WARN: failed to restore daily_sync row:", err);
          });
      } else {
        await db
          .query("DELETE FROM daily_sync WHERE date = $1 AND scope = 'live'", [runDateStr])
          .catch(() => {});
      }
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (j): Mix plan collapses to empty when ALL runs in a shift are ended.
   *
   * After both runs are stopped, liveRunsForMixes returns [] so buildMixPlan
   * returns [] — the plan collapses and the empty-state message appears.
   */
  test("mix plan collapses to empty when all runs in a shift are ended", async ({
    page,
  }) => {
    // This journey intentionally starts and finishes two live runs. On the
    // proxied release preview, the sync/authentication round-trips can put
    // the final navigation just over the suite's 60-second default; keep the
    // assertion bounded without weakening any individual wait.
    test.setTimeout(90_000);

    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId1 = `all-ended-mix-a-${suffix}`;
    const mixId2 = `all-ended-mix-b-${suffix}`;
    const mixName1 = `AllEndedMixA ${suffix}`;
    const mixName2 = `AllEndedMixB ${suffix}`;
    const component1 = `AllEndedCompA_${suffix}`;
    const component2 = `AllEndedCompB_${suffix}`;
    const brand1 = `AllEndedBrandA_${suffix}`;
    const brand2 = `AllEndedBrandB_${suffix}`;
    const today = todayStr();

    try {
      await dbCreateMix(db, {
        id: mixId1,
        name: mixName1,
        brand: brand1,
        isPrep: false,
        component: component1,
        perPizza: 2.0,
        batchSize: 10,
      });
      await dbCreateMix(db, {
        id: mixId2,
        name: mixName2,
        brand: brand2,
        isPrep: false,
        component: component2,
        perPizza: 2.0,
        batchSize: 10,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await page.waitForTimeout(1_000);

      // Set brand on run 1
      await page.locator('[data-testid="tab-run"]').click();
      const brandInput = page.locator('input[placeholder="Brand…"]').first();
      await brandInput.waitFor({ state: "visible", timeout: 10_000 });
      await brandInput.click();
      await brandInput.fill(brand1);
      await brandInput.press("Enter");
      await page.waitForTimeout(800);
      const runId1 = await page.evaluate(() => {
        const day = JSON.parse(localStorage.getItem("run-calc-day") ?? "{}") as {
          runs?: Array<{ id?: string }>;
          currentIndex?: number;
        };
        return day.runs?.[day.currentIndex ?? 0]?.id ?? "";
      });
      expect(runId1).toBeTruthy();

      // Add run 2 and set brand2
      const newRunBtn = page.getByRole("button", { name: /new run/i });
      await newRunBtn.waitFor({ state: "visible", timeout: 8_000 });
      await newRunBtn.click();
      await page.waitForTimeout(800);

      const brandInput2 = page.locator('input[placeholder="Brand…"]').first();
      await brandInput2.waitFor({ state: "visible", timeout: 10_000 });
      await brandInput2.click();
      await brandInput2.fill(brand2);
      await brandInput2.press("Enter");
      await page.waitForTimeout(800);

      // Both cards visible
      await goToMixes(page);
      await page.waitForTimeout(500);
      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText(mixName1, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName2, { exact: false })).toBeVisible({ timeout: 5_000 });

      // Switch to run 1 via Prev, start + stop it
      await page.locator('[data-testid="tab-run"]').click();
      const prevBtn = page.getByRole("button", { name: /prev/i });
      await prevBtn.waitFor({ state: "visible", timeout: 8_000 });
      await prevBtn.click();
      await waitForCurrentRun(page, runId1);

      const startBtn1 = page.locator('[data-testid="button-start-run"]');
      await startBtn1.waitFor({ state: "visible", timeout: 8_000 });
      await startBtn1.click();

      const stopBtn1 = page.getByRole("button", { name: /stop run/i });
      await stopBtn1.waitFor({ state: "visible", timeout: 10_000 });
      await expect(page.getByText("Synchronized", { exact: true })).toBeVisible({
        timeout: 15_000,
      });
      await stopBtn1.click();
      await page.waitForTimeout(800);

      // After stopping run 1: date-group card still present (run 2 active)
      await goToMixes(page);
      await page.waitForTimeout(500);
      await expect(page.locator(`[data-testid="mix-plan-${today}"]`)).toBeVisible({ timeout: 5_000 });

      // Stopping run 1 advances selection to the remaining run. Older builds
      // kept run 1 selected, so only use Next when that legacy state remains.
      await page.locator('[data-testid="tab-run"]').click();
      const nextBtn = page.getByRole("button", { name: /next/i });
      if (await nextBtn.isVisible().catch(() => false)) {
        await nextBtn.click();
        await page.waitForTimeout(600);
      }

      const startBtn2 = page.locator('[data-testid="button-start-run"]');
      await startBtn2.waitFor({ state: "visible", timeout: 8_000 });
      await startBtn2.click();
      const run2Id = await page.evaluate(() => {
        const day = JSON.parse(localStorage.getItem("run-calc-day") ?? "{}") as {
          runs?: Array<{ id?: string }>;
          currentIndex?: number;
        };
        return day.runs?.[day.currentIndex ?? 0]?.id ?? "";
      });

      const stopBtn2 = page.getByRole("button", { name: /stop run/i });
      await stopBtn2.waitFor({ state: "visible", timeout: 10_000 });
      await expect(page.getByText("Synchronized", { exact: true })).toBeVisible({
        timeout: 15_000,
      });
      await stopBtn2.click();
      await waitForLocalRunEnded(page, run2Id);
      await waitForCanonicalRunField(run2Id, "endedAt");
      await expect(page.getByText("Synchronized", { exact: true })).toBeVisible({
        timeout: 15_000,
      });

      // Both runs ended → plan must be empty
      await goToMixes(page);
      await page.waitForTimeout(500);

      await expect(
        page.locator(`[data-testid="mix-plan-${today}"]`),
      ).toHaveCount(0, { timeout: 5_000 });
      await expect(
        page.locator('[data-testid="mix-plan-empty"]'),
      ).toBeVisible({ timeout: 5_000 });
      await expect(page.getByText(mixName1, { exact: false })).toHaveCount(0, { timeout: 3_000 });
      await expect(page.getByText(mixName2, { exact: false })).toHaveCount(0, { timeout: 3_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId1]).catch(() => {});
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId2]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (k): "Already made" value persists after a page reload.
   *
   * Verifies that the onBlur → POST /api/mixes path actually writes to the
   * server (not just the React Query cache), so a hard reload re-fetches the
   * updated value and the Pull For Prep lbs remain reduced accordingly.
   *
   * Formula (same as test f):
   *   componentLbs  = (2.0/16) × 800  = 100.00
   *   totalLbs      = 100.00 × 1.15 + 20 = 135.00
   *   remainingLbs  = 135.00 − 50        =  85.00
   *   pullLbs       = 100.00 × 85.00 / 135.00 ≈ 62.96
   */
  test("'already made' value persists after a page reload (saved to server)", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `persist-reload-${suffix}`;
    const mixName = `PersistReloadPrepMix ${suffix}`;
    const ingredient = `PersistHerb_${suffix}`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 2.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 800
    const MIX_WASTE_FACTOR = 0.15;
    const STARTUP_LBS = 20;
    const componentLbs = (RUN_OZ / 16) * totalPizzas;                     // 100.00
    const totalLbs = componentLbs * (1 + MIX_WASTE_FACTOR) + STARTUP_LBS; // 135.00

    const EDIT_AMOUNT = 50;
    const remainingAfterEdit = totalLbs - EDIT_AMOUNT;                     //  85.00
    const expectedPullLbs = componentLbs * remainingAfterEdit / totalLbs;  // ≈62.96
    const expectedPullStr = expectedPullLbs.toFixed(2);                    // "62.96"
    const fullPullStr = componentLbs.toFixed(2);                           // "100.00"

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: ingredient,
        perPizza: RUN_OZ,
        amountAlreadyMade: 0,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await makeTestUserManager(username);

      // Inject run data into localStorage so the mix card appears
      await page.evaluate(
        ({ brand, ingredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: ingredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, ingredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      // Navigate to Mixes and find the mix card
      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });

      // Step 1: type 50 into "Already made" and blur to trigger POST /api/mixes
      const alreadyMadeInput = todayCard.locator('input[type="number"]').first();
      await alreadyMadeInput.waitFor({ state: "visible", timeout: 5_000 });
      await alreadyMadeInput.click();
      await alreadyMadeInput.fill(String(EDIT_AMOUNT));
      await alreadyMadeInput.blur();

      // Wait for the save round-trip to complete before reloading
      await page.waitForTimeout(2_000);

      // Step 2: Hard-reload the page — flushes the React Query cache entirely
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      // Navigate back to Mixes
      await goToMixes(page);
      await page.waitForTimeout(500);

      const reloadedCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await reloadedCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(reloadedCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });

      // Step 3: "Already made" input must show the saved value (50)
      const savedInput = reloadedCard.locator('input[type="number"]').first();
      await savedInput.waitFor({ state: "visible", timeout: 5_000 });
      await expect(savedInput).toHaveValue(String(EDIT_AMOUNT), { timeout: 5_000 });

      // Step 4: Pull For Prep lbs must reflect the reduced amount (≈62.96), not the full 100.00
      await expect(reloadedCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      const ingredientRow = reloadedCard
        .locator("div", { has: page.getByText(ingredient, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();
      expect(rowText).toContain(expectedPullStr);
      expect(rowText).not.toContain(fullPullStr);
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (k1): Prep mix card appears when the run ingredient uses the COMMA
   * separator variant ("Herb, Chopped") and the mix component is the base
   * name ("Herb").
   *
   * ingredientMatches() accepts ',' as a word-boundary separator (line 1009 of
   * lib/mixes/src/index.ts). A regression that drops ',' from the separator
   * set would silently suppress this card.
   */
  test("prep mix card appears when run ingredient uses comma-separator variant (e.g. 'Herb, Chopped')", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-comma-${suffix}`;
    const mixName = `CommaPrepMix ${suffix}`;

    const componentBase = `Herb_${suffix}`;
    const qualifiedIngredient = `${componentBase}, Chopped`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 3.0;
    const CASES_NEEDED = 80;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 640
    const expectedPullLbs = (RUN_OZ / 16) * totalPizzas; // 120.00

    const MIX_CARD_OZ = 0.1;
    const wrongFallbackLbs = (MIX_CARD_OZ / 16) * totalPizzas; // 4.00

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: componentBase,
        perPizza: MIX_CARD_OZ,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, qualifiedIngredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: qualifiedIngredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, qualifiedIngredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(componentBase, { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(componentBase, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();

      const expectedStr = expectedPullLbs.toFixed(2);       // "120.00"
      const wrongFallbackStr = wrongFallbackLbs.toFixed(2); //   "4.00"

      expect(rowText).toContain(expectedStr);
      expect(rowText).not.toContain(wrongFallbackStr);
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (k2): Prep mix card appears when the run ingredient uses the PAREN
   * separator variant ("Herb (Tidbits)") and the mix component is the base
   * name ("Herb").
   *
   * ingredientMatches() accepts '(' as a word-boundary separator (line 1009 of
   * lib/mixes/src/index.ts). A regression that drops '(' from the separator
   * set would silently suppress this card.
   */
  test("prep mix card appears when run ingredient uses paren-separator variant (e.g. 'Herb (Tidbits)')", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-paren-${suffix}`;
    const mixName = `ParenPrepMix ${suffix}`;

    const componentBase = `Herb_${suffix}`;
    const qualifiedIngredient = `${componentBase} (Tidbits)`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 3.0;
    const CASES_NEEDED = 80;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 640
    const expectedPullLbs = (RUN_OZ / 16) * totalPizzas; // 120.00

    const MIX_CARD_OZ = 0.1;
    const wrongFallbackLbs = (MIX_CARD_OZ / 16) * totalPizzas; // 4.00

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: componentBase,
        perPizza: MIX_CARD_OZ,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, qualifiedIngredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: qualifiedIngredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, qualifiedIngredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(componentBase, { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(componentBase, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();

      const expectedStr = expectedPullLbs.toFixed(2);       // "120.00"
      const wrongFallbackStr = wrongFallbackLbs.toFixed(2); //   "4.00"

      expect(rowText).toContain(expectedStr);
      expect(rowText).not.toContain(wrongFallbackStr);
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (k3): Prep mix card appears when the run ingredient uses the SLASH
   * separator variant ("Herb/Fresh") and the mix component is the base
   * name ("Herb").
   *
   * ingredientMatches() accepts '/' as a word-boundary separator (line 1009 of
   * lib/mixes/src/index.ts). A regression that drops '/' from the separator
   * set would silently suppress this card.
   */
  test("prep mix card appears when run ingredient uses slash-separator variant (e.g. 'Herb/Fresh')", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-slash-${suffix}`;
    const mixName = `SlashPrepMix ${suffix}`;

    const componentBase = `Herb_${suffix}`;
    const qualifiedIngredient = `${componentBase}/Fresh`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 3.0;
    const CASES_NEEDED = 80;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 640
    const expectedPullLbs = (RUN_OZ / 16) * totalPizzas; // 120.00

    const MIX_CARD_OZ = 0.1;
    const wrongFallbackLbs = (MIX_CARD_OZ / 16) * totalPizzas; // 4.00

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: componentBase,
        perPizza: MIX_CARD_OZ,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, qualifiedIngredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: qualifiedIngredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, qualifiedIngredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(componentBase, { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(componentBase, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();

      const expectedStr = expectedPullLbs.toFixed(2);       // "120.00"
      const wrongFallbackStr = wrongFallbackLbs.toFixed(2); //   "4.00"

      expect(rowText).toContain(expectedStr);
      expect(rowText).not.toContain(wrongFallbackStr);
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (k4): Prep mix card appears when the mix component uses the COMMA
   * separator variant ("Herb, Chopped") and the run's pep1Type is the BASE
   * name ("Herb").
   *
   * This is the REVERSE direction of test (k1). ingredientMatches() picks the
   * longer of the two names as the prefix, so it handles both directions.
   * A regression that forgot to normalize or swap longer/shorter would
   * silently suppress the card in this direction while k1 still passes.
   */
  test("prep mix card appears when mix component uses comma-separator qualified name and run uses base name", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-comma-rev-${suffix}`;
    const mixName = `CommaRevPrepMix ${suffix}`;

    const baseIngredient = `Herb_${suffix}`;
    const qualifiedComponent = `${baseIngredient}, Chopped`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 3.0;
    const CASES_NEEDED = 80;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 640
    const expectedPullLbs = (RUN_OZ / 16) * totalPizzas; // 120.00

    const MIX_CARD_OZ = 0.1;
    const wrongFallbackLbs = (MIX_CARD_OZ / 16) * totalPizzas; // 4.00

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: qualifiedComponent,
        perPizza: MIX_CARD_OZ,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, baseIngredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: baseIngredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, baseIngredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(qualifiedComponent, { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(qualifiedComponent, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();

      const expectedStr = expectedPullLbs.toFixed(2);       // "120.00"
      const wrongFallbackStr = wrongFallbackLbs.toFixed(2); //   "4.00"

      expect(rowText).toContain(expectedStr);
      expect(rowText).not.toContain(wrongFallbackStr);
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (k5): Prep mix card appears when the mix component uses the PAREN
   * separator variant ("Herb (Tidbits)") and the run's pep1Type is the BASE
   * name ("Herb").
   *
   * This is the REVERSE direction of test (k2). ingredientMatches() picks the
   * longer of the two names as the prefix, so it handles both directions.
   * A regression that forgot to normalize or swap longer/shorter would
   * silently suppress the card in this direction while k2 still passes.
   */
  test("prep mix card appears when mix component uses paren-separator qualified name and run uses base name", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-paren-rev-${suffix}`;
    const mixName = `ParenRevPrepMix ${suffix}`;

    const baseIngredient = `Herb_${suffix}`;
    const qualifiedComponent = `${baseIngredient} (Tidbits)`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 3.0;
    const CASES_NEEDED = 80;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 640
    const expectedPullLbs = (RUN_OZ / 16) * totalPizzas; // 120.00

    const MIX_CARD_OZ = 0.1;
    const wrongFallbackLbs = (MIX_CARD_OZ / 16) * totalPizzas; // 4.00

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: qualifiedComponent,
        perPizza: MIX_CARD_OZ,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, baseIngredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: baseIngredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
        { brand, baseIngredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
      );

      await stampLocalFixtureForReload(page);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(qualifiedComponent, { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(qualifiedComponent, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();

      const expectedStr = expectedPullLbs.toFixed(2);       // "120.00"
      const wrongFallbackStr = wrongFallbackLbs.toFixed(2); //   "4.00"

      expect(rowText).toContain(expectedStr);
      expect(rowText).not.toContain(wrongFallbackStr);
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (k6): Prep mix card appears when the mix component uses the SLASH
   * separator variant ("Herb/Fresh") and the run's pep1Type is the BASE
   * name ("Herb").
   *
   * This is the REVERSE direction of test (k3). ingredientMatches() picks the
   * longer of the two names as the prefix, so it handles both directions.
   * A regression that forgot to normalize or swap longer/shorter would
   * silently suppress the card in this direction while k3 still passes.
   */
  test("prep mix card appears when mix component uses slash-separator qualified name and run uses base name", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `prep-slash-rev-${suffix}`;
    const mixName = `SlashRevPrepMix ${suffix}`;

    const baseIngredient = `Herb_${suffix}`;
     const qualifiedComponent = `${baseIngredient}/Fresh`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const RUN_OZ = 3.0;
    const CASES_NEEDED = 80;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 640
    const expectedPullLbs = (RUN_OZ / 16) * totalPizzas; // 120.00

    const MIX_CARD_OZ = 0.1;
    const wrongFallbackLbs = (MIX_CARD_OZ / 16) * totalPizzas; // 4.00

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        isPrep: true,
        component: qualifiedComponent,
        perPizza: MIX_CARD_OZ,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");

      await page.evaluate(
        ({ brand, baseIngredient, runOz, casesNeeded, pizzasPerCase }) => {
          const DAY_KEY = "run-calc-day";
          const RUN_KEY = (id: string) => `run-calc-run-${id}`;
          const rawDay = localStorage.getItem(DAY_KEY);
          if (!rawDay) return;
          const day = JSON.parse(rawDay) as { runs?: Array<{ id: string; brand?: string }> };
          if (!day.runs || day.runs.length === 0) return;
          day.runs[0].brand = brand;
          localStorage.setItem(DAY_KEY, JSON.stringify(day));
          const runId = day.runs[0].id;
          const existing = (() => {
            try { return JSON.parse(localStorage.getItem(RUN_KEY(runId)) ?? "{}"); } catch { return {}; }
          })();
          localStorage.setItem(RUN_KEY(runId), JSON.stringify({
            ...existing, pep1Type: baseIngredient, pep1OzPerPizza: runOz,
            casesNeeded, pizzasPerCase, casesPerLayer: 0,
          }));
        },
       { brand, baseIngredient, runOz: RUN_OZ, casesNeeded: CASES_NEEDED, pizzasPerCase: PIZZAS_PER_CASE },
     );

     await stampLocalFixtureForReload(page);
     await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });

      await expect(todayCard.getByText("Ingredient Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Prep", { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(qualifiedComponent, { exact: false })).toBeVisible({ timeout: 5_000 });

      const ingredientRow = todayCard
        .locator("div", { has: page.getByText(qualifiedComponent, { exact: true }) })
        .last();
      const rowText = await ingredientRow.innerText();

      const expectedStr = expectedPullLbs.toFixed(2);       // "120.00"
      const wrongFallbackStr = wrongFallbackLbs.toFixed(2); //   "4.00"

      expect(rowText).toContain(expectedStr);
      expect(rowText).not.toContain(wrongFallbackStr);
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (k): Empty state is preserved after a full page reload when all runs
   * are ended — exercises the localStorage + React hydration path separately
   * from the in-memory state path.
   *
   * Mechanism: liveRunsForMixes (home.tsx ~14462) re-derives its list from
   * dayState.runs on every render. loadDayState() on mount reads the persisted
   * day state from localStorage, which carries endedAt on every run. If the
   * filter regresses on the hydration path (e.g. endedAt is lost during
   * serialisation), the plan would wrongly re-appear after reload even though
   * it was empty in the same browser session.
   *
   * This test shares the same two-run stop sequence as test (j) and then adds
   * a full page reload before the final empty-state assertion.
   */

  /**
   * Test (l): Empty state is preserved after a full page reload when all runs
   * are ended — exercises the localStorage + React hydration path separately
   * from the in-memory state path.
   */
  test("empty state is preserved after a page reload when all runs are ended", async ({
    page,
  }) => {
    // This two-run start/stop/reload journey can exceed the suite's 60-second
    // default under full-run load; keep a bounded, case-local budget.
    test.setTimeout(90_000);
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId1 = `reload-ended-mix-a-${suffix}`;
    const mixId2 = `reload-ended-mix-b-${suffix}`;
    const mixName1 = `ReloadEndedMixA ${suffix}`;
    const mixName2 = `ReloadEndedMixB ${suffix}`;
    const component1 = `ReloadEndedCompA_${suffix}`;
    const component2 = `ReloadEndedCompB_${suffix}`;
    const brand1 = `ReloadEndedBrandA_${suffix}`;
    const brand2 = `ReloadEndedBrandB_${suffix}`;
    const today = todayStr();
    const runId1 = `reload-ended-run-a-${suffix}`;
    const runId2 = `reload-ended-run-b-${suffix}`;

    try {
      await dbCreateMix(db, {
        id: mixId1,
        name: mixName1,
        brand: brand1,
        isPrep: false,
        component: component1,
        perPizza: 2.0,
        batchSize: 10,
      });
      await dbCreateMix(db, {
        id: mixId2,
        name: mixName2,
        brand: brand2,
        isPrep: false,
        component: component2,
        perPizza: 2.0,
        batchSize: 10,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await seedLiveRunsAfterAppLoad(page, [
        {
          runId: runId1,
          brand: brand1,
          ingredient: component1,
          runOz: 2,
          casesNeeded: 1,
          pizzasPerCase: 8,
          casesPerLayer: 0,
        },
        {
          runId: runId2,
          brand: brand2,
          ingredient: component2,
          runOz: 2,
          casesNeeded: 1,
          pizzasPerCase: 8,
          casesPerLayer: 0,
        },
      ], 1);

      // Both cards visible before any run is stopped
      await goToMixes(page);
      await page.waitForTimeout(500);
      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText(mixName1, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText(mixName2, { exact: false })).toBeVisible({ timeout: 5_000 });

      // Switch to run 1 via Prev, start + stop it
      await page.locator('[data-testid="tab-run"]').click();
      const prevBtn = page.getByRole("button", { name: /prev/i });
      await prevBtn.waitFor({ state: "visible", timeout: 8_000 });
      await prevBtn.click();
      await page.waitForTimeout(600);

      const startBtn1 = page.locator('[data-testid="button-start-run"]');
      await startBtn1.waitFor({ state: "visible", timeout: 8_000 });
      await startBtn1.click();
      await waitForLocalRunStarted(page, runId1);
      await waitForCanonicalRunField(runId1, "startedAt");

      // Starting the next run is the supported transition between runs: it
      // auto-ends the active run, avoiding a second START during the first
      // stop's foreground-adoption fence.
      const nextBtn = page.getByRole("button", { name: /next/i });
      await nextBtn.waitFor({ state: "visible", timeout: 8_000 });
      await nextBtn.click();
      await waitForCurrentRun(page, runId2);

      const startBtn2 = page.locator('[data-testid="button-start-run"]');
      await startBtn2.waitFor({ state: "visible", timeout: 8_000 });
      await startBtn2.click();
      await waitForLocalRunStarted(page, runId2);
      await waitForCanonicalRunField(runId2, "startedAt");
      await waitForLocalRunEnded(page, runId1);
      await waitForCanonicalRunField(runId1, "endedAt");

      const stopBtn2 = page.getByRole("button", { name: /stop run/i });
      await stopBtn2.waitFor({ state: "visible", timeout: 10_000 });
      await stopBtn2.click();
      await waitForLocalRunEnded(page, runId2);
      await waitForCanonicalRunField(runId2, "endedAt");

      // ── Full page reload ──────────────────────────────────────────────────────
      // This exercises the localStorage → loadDayState() → React hydration path.
      // endedAt must survive serialisation so liveRunsForMixes returns [] and
      // buildMixPlan returns [] after mount.
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      // Dismiss onboarding if it reappears after reload (it should not, but be safe).
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      // Navigate to Mixes and assert empty state is still shown
      await goToMixes(page);
      await page.waitForTimeout(500);

      await expect(
        page.locator(`[data-testid="mix-plan-${today}"]`),
      ).toHaveCount(0, { timeout: 5_000 });
      await expect(
        page.locator('[data-testid="mix-plan-empty"]'),
      ).toBeVisible({ timeout: 5_000 });
      await expect(page.getByText(mixName1, { exact: false })).toHaveCount(0, { timeout: 3_000 });
      await expect(page.getByText(mixName2, { exact: false })).toHaveCount(0, { timeout: 3_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId1]).catch(() => {});
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId2]).catch(() => {});
      await db.query("DELETE FROM daily_sync WHERE date = $1 AND scope = 'live'", [today]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (l): Empty state is preserved after a cold page reload when all runs
   * are ended and Mixes was never opened in the previous page session.
   *
   * Unlike the preceding reload test, this deliberately stops both runs while
   * staying on the Run tab. The first Mixes navigation happens only after the
   * reload, exercising hydration without any previously-populated Mixes state.
   */
  test("shows the empty state on first Mixes visit after a cold reload with all runs ended", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId1 = `cold-reload-ended-mix-a-${suffix}`;
    const mixId2 = `cold-reload-ended-mix-b-${suffix}`;
    const mixName1 = `ColdReloadEndedMixA ${suffix}`;
    const mixName2 = `ColdReloadEndedMixB ${suffix}`;
    const component1 = `ColdReloadEndedCompA_${suffix}`;
    const component2 = `ColdReloadEndedCompB_${suffix}`;
    const brand1 = `ColdReloadEndedBrandA_${suffix}`;
    const brand2 = `ColdReloadEndedBrandB_${suffix}`;
    const today = todayStr();
    const runId1 = `cold-reload-ended-run-a-${suffix}`;
    const runId2 = `cold-reload-ended-run-b-${suffix}`;

    try {
      await dbCreateMix(db, {
        id: mixId1,
        name: mixName1,
        brand: brand1,
        isPrep: false,
        component: component1,
        perPizza: 2.0,
        batchSize: 10,
      });
      await dbCreateMix(db, {
        id: mixId2,
        name: mixName2,
        brand: brand2,
        isPrep: false,
        component: component2,
        perPizza: 2.0,
        batchSize: 10,
      });

      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await seedLiveRunsAfterAppLoad(page, [
        {
          runId: runId1,
          brand: brand1,
          ingredient: component1,
          runOz: 2,
          casesNeeded: 1,
          pizzasPerCase: 8,
          casesPerLayer: 0,
        },
        {
          runId: runId2,
          brand: brand2,
          ingredient: component2,
          runOz: 2,
          casesNeeded: 1,
          pizzasPerCase: 8,
          casesPerLayer: 0,
        },
      ], 1);

      // Complete both runs without visiting Mixes. The cold reload below must
      // be followed by this browser's first Mixes visit.
      const prevBtn = page.getByRole("button", { name: /prev/i });
      await prevBtn.waitFor({ state: "visible", timeout: 8_000 });
      await prevBtn.click();
      await waitForCurrentRun(page, runId1);

      const startBtn1 = page.locator('[data-testid="button-start-run"]');
      await startBtn1.waitFor({ state: "visible", timeout: 8_000 });
      await startBtn1.click();
      await waitForLocalRunStarted(page, runId1);
      await waitForCanonicalRunField(runId1, "startedAt");
      await expect(page.getByText("Synchronized", { exact: true })).toBeVisible({
        timeout: 15_000,
      });

      const nextBtn = page.getByRole("button", { name: /next/i });
      await nextBtn.waitFor({ state: "visible", timeout: 8_000 });
      await nextBtn.click();
      await waitForCurrentRun(page, runId2);

      const startBtn2 = page.locator('[data-testid="button-start-run"]');
      await startBtn2.waitFor({ state: "visible", timeout: 8_000 });
      await startBtn2.click();
      await waitForLocalRunStarted(page, runId2);
      await waitForCanonicalRunField(runId2, "startedAt");
      await waitForLocalRunEnded(page, runId1);

      const stopBtn2 = page.getByRole("button", { name: /stop run/i });
      await stopBtn2.waitFor({ state: "visible", timeout: 10_000 });
      await stopBtn2.click();
      await waitForLocalRunEnded(page, runId2);
      await waitForCanonicalRunField(runId2, "endedAt");

      // Reload before the first Mixes visit in this browser session.
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      await expect(page.locator(`[data-testid="mix-plan-${today}"]`)).toHaveCount(0, {
        timeout: 5_000,
      });
      await expect(page.locator('[data-testid="mix-plan-empty"]')).toBeVisible({
        timeout: 5_000,
      });
      await expect(page.getByText(mixName1, { exact: false })).toHaveCount(0, {
        timeout: 3_000,
      });
      await expect(page.getByText(mixName2, { exact: false })).toHaveCount(0, {
        timeout: 3_000,
      });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId1]).catch(() => {});
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId2]).catch(() => {});
      await db.query("DELETE FROM daily_sync WHERE date = $1 AND scope = 'live'", [today]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (m): Batch count on a regular mix card updates live when 'already made'
   * is edited — Task #798.
   *
   * Mechanism: onBlur → saveMixes → onSaved → cycleCountQc.setQueryData(["mixes"],
   * saved) → buildMixPlan re-runs → m.batches = remainingLbs / batchSize
   * re-derives → the batch count span re-renders immediately without reload.
   *
   * Formula (lib/mixes/src/index.ts, computeEntry):
   *   componentLbs  = (2.0/16) × 800           = 100.00
   *   wasteLbs      = 100.00 × 0.15             =  15.00
   *   startupLbs    = 20
   *   totalLbs      = 100.00 + 15.00 + 20       = 135.00
   *
   *   initial  (amountAlreadyMade = 0  ): batches = 135.00 / 10 = 13.50
   *   partial  (amountAlreadyMade = 50 ): batches =  85.00 / 10 =  8.50
   *   full     (amountAlreadyMade = 135): batches =   0.00 / 10 =  0.00
   */
  test("batch count on a regular mix card updates live when 'already made' is edited", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `batch-live-${suffix}`;
    const mixName = `BatchLiveMix ${suffix}`;
    const component = `BatchComp_${suffix}`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const BATCH_SIZE = 10;
    const PER_PIZZA_OZ = 2.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 800

    const MIX_WASTE_FACTOR = 0.15;
    const STARTUP_LBS = 20;
    const componentLbs = (PER_PIZZA_OZ / 16) * totalPizzas;               // 100.00
    const totalLbs = componentLbs * (1 + MIX_WASTE_FACTOR) + STARTUP_LBS; // 135.00

    const initialBatches = totalLbs / BATCH_SIZE;           // 13.50
    const initialBatchesStr = initialBatches.toFixed(2);    // "13.50"

    const EDIT_AMOUNT = 50;
    const remainingAfterEdit = totalLbs - EDIT_AMOUNT;      //  85.00
    const batchesAfterEdit = remainingAfterEdit / BATCH_SIZE; //  8.50
    const batchesAfterEditStr = batchesAfterEdit.toFixed(2); // "8.50"

    const FULL_AMOUNT = Math.ceil(totalLbs); // 135 — covers totalLbs exactly

    try {
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        brand,
        isPrep: false,
        component,
        perPizza: PER_PIZZA_OZ,
        batchSize: BATCH_SIZE,
        amountAlreadyMade: 0,
      });

      await seedLiveRunBeforeAppLoad(page, {
        runId: `batch-live-run-${suffix}`,
        brand,
        ingredient: component,
        runOz: PER_PIZZA_OZ,
        casesNeeded: CASES_NEEDED,
        pizzasPerCase: PIZZAS_PER_CASE,
        casesPerLayer: 0,
      });
      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await makeTestUserManager(username);
      await page.goto("/", { waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });

      // The innermost div containing the mix name is the mix card itself.
      // The plan card contains both the summary and the editable amount. Keep
      // the locator at the card level: the innermost name-matching div can be
      // the component summary and omit the sibling "Already made" input.
      const mixCard = todayCard;

      // ── Step 1: initial batch count (amountAlreadyMade = 0) ──────────────────
      // batches = 135.00 / 10 = 13.50
      await expect(mixCard.getByText(new RegExp(initialBatchesStr))).toBeVisible({ timeout: 5_000 });
      await expect(mixCard.getByText(/batches/, { exact: false })).toBeVisible({ timeout: 3_000 });

      // ── Step 2: type 50 and blur ─────────────────────────────────────────────
      const alreadyMadeInput = mixCard.locator('input[type="number"]').first();
      await alreadyMadeInput.waitFor({ state: "visible", timeout: 5_000 });
      await alreadyMadeInput.click();
      await alreadyMadeInput.fill(String(EDIT_AMOUNT));
      await alreadyMadeInput.blur();
      await page.waitForTimeout(1_500);

      // ── Step 3: batch count updates to 8.50 batches ──────────────────────────
      await expect(mixCard.getByText(new RegExp(batchesAfterEditStr))).toBeVisible({ timeout: 5_000 });
      // The "need X lbs" badge reflects the new remainingLbs
      await expect(
        todayCard.getByText(`need ${remainingAfterEdit.toFixed(2)} lbs`, { exact: false }),
      ).toBeVisible({ timeout: 3_000 });
      // Old batch count is gone
      await expect(mixCard.getByText(new RegExp(initialBatchesStr))).toHaveCount(0, { timeout: 3_000 });

      // ── Step 4: type amountAlreadyMade >= totalLbs ───────────────────────────
      await alreadyMadeInput.click();
      await alreadyMadeInput.fill(String(FULL_AMOUNT));
      await alreadyMadeInput.blur();
      await page.waitForTimeout(1_500);

      // ── Step 5: batch count drops to 0.00 ────────────────────────────────────
      // remainingLbs = max(0, 135 - 135) = 0 → batches = 0 / 10 = 0.00
      await expect(mixCard.getByText("0.00 batches", { exact: true })).toBeVisible({ timeout: 5_000 });
      // Partial batch count from step 3 is gone
      await expect(mixCard.getByText(new RegExp(batchesAfterEditStr))).toHaveCount(0, { timeout: 3_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (l): Batch count is correct on cold page load when amountAlreadyMade
   * is already persisted in the DB (Task #818 target).
   *
   * The cold-load path is distinct from the live-edit path tested above:
   * on mount, useMixes fetches mixes from the server which returns the
   * persisted amountAlreadyMade. buildMixPlan must use that value so the
   * first render shows the correct batch count, not the 0-based count.
   *
   * Formula:
   *   totalPizzas  = CASES_NEEDED × PIZZAS_PER_CASE = 100 × 8 = 800
   *   componentLbs = (PER_PIZZA_OZ / 16) × totalPizzas = (2.0/16) × 800 = 100.00
   *   totalLbs     = componentLbs × 1.15 + 20 = 135.00
   *   remainingLbs = totalLbs − AMOUNT_ALREADY_MADE = 135.00 − 50 = 85.00
   *   batches      = remainingLbs / BATCH_SIZE = 85.00 / 10 = 8.50
   *
   * If amountAlreadyMade were ignored/zeroed on cold load the displayed
   * count would be 135.00 / 10 = 13.50.
   */
  test("batch count on cold load uses persisted amountAlreadyMade from the server", async ({
    page,
  }) => {
    // Full-suite authenticated bootstrap can require one recovery reload after
    // a prior test's local state is replaced. Keep the complete assertion
    // sequence intact while allowing that deterministic recovery to finish.
    test.setTimeout(90_000);
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `cold-batch-${suffix}`;
    const mixName = `ColdBatchMix ${suffix}`;
    const component = `ColdComp_${suffix}`;
    const brand = `ColdBrand_${suffix}`;
    const today = todayStr();
    const runId = `cold-batch-run-${suffix}`;

    const BATCH_SIZE = 10;
    const PER_PIZZA_OZ = 2.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const AMOUNT_ALREADY_MADE = 50;

    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE;                      // 800
    const componentLbs = (PER_PIZZA_OZ / 16) * totalPizzas;                  // 100.00
    const MIX_WASTE_FACTOR = 0.15;
    const STARTUP_LBS = 20;
    const totalLbs = componentLbs * (1 + MIX_WASTE_FACTOR) + STARTUP_LBS;    // 135.00
    const remainingLbs = totalLbs - AMOUNT_ALREADY_MADE;                      //  85.00
    const expectedBatches = remainingLbs / BATCH_SIZE;                        //   8.50
    const expectedBatchesStr = expectedBatches.toFixed(2);                    // "8.50"
    const wrongBatches = totalLbs / BATCH_SIZE;                               //  13.50
    const wrongBatchesStr = wrongBatches.toFixed(2);                          // "13.50"

    try {
      // ── Step 1: create the mix in the DB with amountAlreadyMade > 0 ──────────
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        brand,
        isPrep: false,
        component,
        perPizza: PER_PIZZA_OZ,
        batchSize: BATCH_SIZE,
        amountAlreadyMade: AMOUNT_ALREADY_MADE,
      });

      // ── Step 2: seed the run before authenticated bootstrap ──────────────────
      await seedLiveRunBeforeAppLoad(page, {
        runId,
        brand,
        ingredient: component,
        runOz: PER_PIZZA_OZ,
        casesNeeded: CASES_NEEDED,
        pizzasPerCase: PIZZAS_PER_CASE,
        casesPerLayer: 0,
      });
      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      const seedStamp = Date.now();
      await db.query(
        `INSERT INTO daily_sync (date, scope, data, updated_at)
         VALUES ($1, 'live', $2::jsonb, NOW())
         ON CONFLICT (date, scope) DO UPDATE
           SET data = $2::jsonb, updated_at = NOW()`,
        [today, JSON.stringify({
          dayState: {
            runs: [{ id: runId, brand, flavor: "", seeded: false, metaUpdatedAt: seedStamp }],
            currentIndex: 0,
            currentRunId: runId,
            date: today,
            resetAt: 0,
          },
          runValues: {
            [runId]: {
              pep1Type: component,
              pep1OzPerPizza: PER_PIZZA_OZ,
              casesNeeded: CASES_NEEDED,
              pizzasPerCase: PIZZAS_PER_CASE,
              casesPerLayer: 0,
            },
          },
          runValuesUpdatedAt: { [runId]: seedStamp },
        })],
      );

      // ── Step 3: full page reload — this is the cold-load path ────────────────
      // On mount, useMixes fetches from the server (which returns the DB row with
      // amountAlreadyMade = 50). buildMixPlan must use that value immediately.
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      // ── Step 4: open Mixes tab ───────────────────────────────────────────────
      await goToMixes(page);
      await page.waitForTimeout(500);

      // ── Step 5: verify the mix card is present ───────────────────────────────
      const todayCard = await waitForTodayMixPlanCard(page, today);
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });

      const mixCard = todayCard
        .locator("div", { has: page.getByText(mixName, { exact: true }) })
        .last();

      // ── Step 6: batch count must use the persisted amountAlreadyMade ─────────
      // Correct:   remainingLbs / batchSize = 85.00 / 10 = 8.50 batches
      // Wrong:     totalLbs / batchSize     = 135.00 / 10 = 13.50 batches
      await expect(
        mixCard.getByText(new RegExp(expectedBatchesStr)),
      ).toBeVisible({ timeout: 5_000 });
      await expect(
        mixCard.getByText(/batch/, { exact: false }),
      ).toBeVisible({ timeout: 3_000 });
      await expect(
        mixCard.getByText(new RegExp(wrongBatchesStr)),
      ).toHaveCount(0, { timeout: 3_000 });

      // ── Step 7: "need X lbs" badge reflects the correct remainingLbs ─────────
      await expect(
        todayCard.getByText(`need ${remainingLbs.toFixed(2)} lbs`, { exact: false }),
      ).toBeVisible({ timeout: 5_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });

  /**
   * Test (n): Pull For Mix per-component lbs on a REGULAR (non-prep) mix card
   * update live when "already made" is edited. — Task #799.
   *
   * Regular mixes are brand/flavor-matched (not ingredient-matched like prep
   * mixes). Component pull lbs come from the mix's own perPizza value scaled to
   * the run's pizza count. The live formula in home.tsx ~14596:
   *
   *   pullLbs = m.totalLbs > 0 ? c.lbs * m.remainingLbs / m.totalLbs : 0
   *
   * where:
   *   c.lbs        = (perPizza / 16) × pizzas  — constant, doesn't change
   *   m.totalLbs   = c.lbs × 1.15 + 20         — constant, doesn't change
   *   m.remainingLbs = max(0, totalLbs − amountAlreadyMade) — changes on edit
   *
   * Scenario numbers:
   *   components   = 2.0 oz + 1.0 oz
   *   casesNeeded  = 100,  pizzasPerCase = 8  →  pizzas = 800
   *   c1.lbs       = (2.0/16) × 800 = 100.00
   *   c2.lbs       = (1.0/16) × 800 =  50.00
   *   totalLbs     = (100.00 + 50.00) × 1.15 + 20 = 192.50
   *
   *   Step 1 (amountAlreadyMade = 0):
   *     remainingLbs = 192.50 → c1=100.00, c2=50.00 ✓
   *
   *   Step 2 (amountAlreadyMade = 50):
   *     remainingLbs = 142.50  → c1≈74.03, c2≈37.01 ✓
   *
   *   Step 3 (amountAlreadyMade = 200 ≥ totalLbs):
   *     remainingLbs = 0      → c1=0.00, c2=0.00 ✓
   *
   * The update must happen without a page reload — MixAlreadyMadeInput onBlur
   * → saveMixes → onSaved → cycleCountQc.setQueryData(["mixes"], saved) →
   * buildMixPlan re-runs → Pull For Mix re-renders.
   */
  test("Pull For Mix per-component lbs on a regular mix card update live when 'already made' is edited", async ({
    page,
  }) => {
    const suffix = uid();
    const username = `user_${suffix}`;
    const mixId = `reg-pull-live-${suffix}`;
    const mixName = `RegPullLiveMix ${suffix}`;
    const component1 = `RegCompA_${suffix}`;
    const component2 = `RegCompB_${suffix}`;
    const brand = `Brand_${suffix}`;
    const today = todayStr();

    const COMPONENT_1_PER_PIZZA_OZ = 2.0;
    const COMPONENT_2_PER_PIZZA_OZ = 1.0;
    const CASES_NEEDED = 100;
    const PIZZAS_PER_CASE = 8;
    const totalPizzas = CASES_NEEDED * PIZZAS_PER_CASE; // 800

    const component1Lbs = (COMPONENT_1_PER_PIZZA_OZ / 16) * totalPizzas; // 100.00
    const component2Lbs = (COMPONENT_2_PER_PIZZA_OZ / 16) * totalPizzas; // 50.00
    const componentLbs = component1Lbs + component2Lbs; // 150.00
    const MIX_WASTE_FACTOR = 0.15;
    const STARTUP_LBS = 20;
    const totalLbs = componentLbs * (1 + MIX_WASTE_FACTOR) + STARTUP_LBS; // 192.50

    // ── Step 1 expected: full pull (amountAlreadyMade = 0) ──────────────────
    const fullPull1Str = component1Lbs.toFixed(2); // "100.00"
    const fullPull2Str = component2Lbs.toFixed(2); // "50.00"

    // ── Step 2 expected: partial pull (amountAlreadyMade = 50) ──────────────
    const EDIT_PARTIAL = 50;
    const remainingAfterPartial = totalLbs - EDIT_PARTIAL; // 142.50
    const scaledPull1Str = (component1Lbs * remainingAfterPartial / totalLbs).toFixed(2); // "74.03"
    const scaledPull2Str = (component2Lbs * remainingAfterPartial / totalLbs).toFixed(2); // "37.01"

    // ── Step 3 expected: zero pull (amountAlreadyMade >= totalLbs) ──────────
    const EDIT_FULL = Math.ceil(totalLbs) + 1; // 136, safely >= 135.00

    try {
      // Create a regular mix with two components whose pull amounts differ.
      await dbCreateMix(db, {
        id: mixId,
        name: mixName,
        brand,
        isPrep: false,
        component: component1,
        components: [
          { ingredient: component1, perPizza: COMPONENT_1_PER_PIZZA_OZ },
          { ingredient: component2, perPizza: COMPONENT_2_PER_PIZZA_OZ },
        ],
        perPizza: COMPONENT_1_PER_PIZZA_OZ,
        batchSize: 0,
        amountAlreadyMade: 0,
      });

      await seedLiveRunBeforeAppLoad(page, {
        runId: `reg-pull-live-run-${suffix}`,
        brand,
        ingredient: component1,
        runOz: COMPONENT_1_PER_PIZZA_OZ,
        casesNeeded: CASES_NEEDED,
        pizzasPerCase: PIZZAS_PER_CASE,
        casesPerLayer: 0,
      });
      await signUpAndDismissOnboarding(page, username, "TestPass123!");
      await makeTestUserManager(username);
      await page.goto("/", { waitUntil: "domcontentloaded" });
      await page.locator('[data-testid="tab-run"]').waitFor({ state: "attached", timeout: 25_000 });
      await page.getByRole("button", { name: /^get.?started$/i })
        .waitFor({ state: "visible", timeout: 5_000 }).then((b) => b.click()).catch(() => {});
      await page.waitForTimeout(1_000);

      await goToMixes(page);
      await page.waitForTimeout(500);

      const todayCard = page.locator(`[data-testid="mix-plan-${today}"]`);
      await todayCard.waitFor({ state: "visible", timeout: 8_000 });
      await expect(todayCard.getByText(mixName, { exact: false })).toBeVisible({ timeout: 5_000 });
      await expect(todayCard.getByText("Pull For Mix", { exact: false })).toBeVisible({ timeout: 5_000 });

      // ── Step 1: full pull shown when amountAlreadyMade = 0 ─────────────────
      // Locate the component row inside the Pull For Mix section.
      const component1Row = todayCard
        .locator("div", { has: page.getByText(component1, { exact: true }) })
        .last();
      const component2Row = todayCard
        .locator("div", { has: page.getByText(component2, { exact: true }) })
        .last();
      await expect(component1Row).toContainText(fullPull1Str, { timeout: 5_000 });
      await expect(component2Row).toContainText(fullPull2Str, { timeout: 5_000 });

      // ── Step 2: type 50 and blur — pull must scale down immediately ─────────
      // The "Already made" input lives on the regular mix card (emerald section,
      // NOT the violet Ingredient Prep section).
      const alreadyMadeInput = todayCard.locator('input[type="number"]').first();
      await alreadyMadeInput.waitFor({ state: "visible", timeout: 5_000 });
      await alreadyMadeInput.click();
      await alreadyMadeInput.fill(String(EDIT_PARTIAL));
      await alreadyMadeInput.blur();

      // Polling assertion: waits until both component rows re-render with scaled lbs.
      await expect(component1Row).toContainText(scaledPull1Str, { timeout: 5_000 });
      await expect(component2Row).toContainText(scaledPull2Str, { timeout: 5_000 });
      // Neither full unscaled value may remain (regression guard).
      await expect(component1Row).not.toContainText(fullPull1Str, { timeout: 3_000 });
      await expect(component2Row).not.toContainText(fullPull2Str, { timeout: 3_000 });

      // ── Step 3: type a value >= totalLbs — pull must reach 0.00 ────────────
      await alreadyMadeInput.click();
      await alreadyMadeInput.fill(String(EDIT_FULL));
      await alreadyMadeInput.blur();

      // Polling assertion: both component rows must show 0.00 once remainingLbs
      // clamps to 0.
      await expect(component1Row).toContainText("0.00", { timeout: 5_000 });
      await expect(component2Row).toContainText("0.00", { timeout: 5_000 });
    } finally {
      await db.query("DELETE FROM mixes WHERE id = $1", [mixId]).catch(() => {});
      await db.query("DELETE FROM users WHERE username = $1", [username]).catch(() => {});
    }
  });
});
